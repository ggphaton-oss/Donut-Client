package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Drawing helpers + theme. Everything is plain DrawContext fills/text, no custom shaders. */
public final class Gfx {
    private Gfx() {}

    // Theme (RGB, alpha is applied separately)
    public static final int BG = 0x0A0F1E, PANEL = 0x10172B, CARD = 0x16203A, CARD_H = 0x1F2D52;
    public static final int BLUE = 0x2F7BFF, BLUE2 = 0x6AAEFF, TAN = 0xE8A56B;
    public static final int TEXT = 0xE8EEFF, DIM = 0x8E9BC0, OFF = 0x2A3556;
    public static final int GREEN = 0x4ADE80, RED = 0xFF5C6C;

    /** Live GUI accent (from the Theme module, can be rainbow). */
    public static int accent() { return Modules.theme == null ? BLUE : Modules.theme.color.rgb(0f); }
    public static int accent2() { return mix(accent(), 0xFFFFFF, 0.35f); }

    /** HSB (all 0..1) to 0xRRGGBB. */
    public static int hsb(float h, float s, float b) {
        h = h - (float) Math.floor(h);
        float r = 0, g = 0, bl = 0;
        float f = (h - (float) Math.floor(h)) * 6f;
        int i = (int) f;
        float fr = f - i, p = b * (1 - s), q = b * (1 - s * fr), t = b * (1 - s * (1 - fr));
        switch (i % 6) {
            case 0 -> { r = b; g = t; bl = p; }
            case 1 -> { r = q; g = b; bl = p; }
            case 2 -> { r = p; g = b; bl = t; }
            case 3 -> { r = p; g = q; bl = b; }
            case 4 -> { r = t; g = p; bl = b; }
            default -> { r = b; g = p; bl = q; }
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(bl * 255);
    }

    /** Frame-rate independent smoothing animation. Owns its own clock. */
    public static final class Anim {
        public float v;
        private long last = System.nanoTime();

        public Anim(float start) { this.v = start; }

        public float update(float target, float speed) {
            long n = System.nanoTime();
            float dt = Math.min((n - last) / 1e9f, 0.05f);
            last = n;
            v += (target - v) * (1f - (float) Math.exp(-speed * dt));
            if (Math.abs(target - v) < 0.002f) v = target;
            return v;
        }
    }

    public static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    public static float ease(float t) { t = clamp(t, 0, 1); float u = 1 - t; return 1 - u * u * u; }

    public static int col(int rgb, float alpha) {
        int a = Math.round(clamp(alpha, 0, 1) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = clamp(t, 0, 1);
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int w(String s) { return MinecraftClient.getInstance().textRenderer.getWidth(s); }

    public static void text(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        if (alpha < 0.03f) return; // very low alpha text can render opaque
        c.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, col(rgb, alpha), false);
    }

    public static void boldText(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        if (alpha < 0.03f) return;
        c.drawText(MinecraftClient.getInstance().textRenderer,
                Text.literal(s).formatted(net.minecraft.util.Formatting.BOLD), x, y, col(rgb, alpha), false);
    }

    /** Rounded rectangle built from row strips. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, color); return; }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** Animated toggle switch. on = 0..1 */
    public static void toggle(DrawContext c, int x, int y, float on, float alpha) {
        rrect(c, x, y, 26, 12, 6, col(mix(OFF, accent(), on), alpha));
        int kx = x + 2 + Math.round(14 * on);
        rrect(c, kx, y + 2, 8, 8, 4, col(0xFFFFFF, alpha));
    }

    /** Little donut logo made from two rounded rects. */
    public static void donut(DrawContext c, int x, int y, int size, int holeBg, float alpha) {
        rrect(c, x, y, size, size, size / 2, col(accent(), alpha));
        int h = size / 3;
        rrect(c, x + (size - h) / 2, y + (size - h) / 2, h, h, h / 2, col(holeBg, alpha));
    }
}
