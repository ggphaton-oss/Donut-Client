package dev.donutmm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Safety lock: modules only run in singleplayer (optional) or on hosts in the allow list.
 * The list is editable live from the "Server Lock" tab of the GUI and saved to config/donutmm.json,
 * so no recompiling. DonutSMP is hard-blocked in code and cannot be added.
 */
public final class ServerLock {
    private ServerLock() {}

    private static final String[] HARD_BLOCK = {"donutsmp"};

    public static final class Config {
        public List<String> allowedHosts = new ArrayList<>(List.of("localhost", "127.0.0.1"));
        public boolean disconnectOnBlocked = true;
        public boolean allowSingleplayer = true;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config cfg = new Config();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("donutmm.json"); }

    public static void load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                Config read = GSON.fromJson(Files.readString(p), Config.class);
                if (read != null && read.allowedHosts != null) cfg = read;
            } else {
                save();
            }
        } catch (Exception e) {
            System.err.println("[DonutMM] config error, using defaults: " + e);
        }
    }

    public static void save() {
        try { Files.writeString(path(), GSON.toJson(cfg)); }
        catch (Exception e) { System.err.println("[DonutMM] could not save donutmm.json: " + e); }
    }

    public static boolean disconnectOnBlocked() { return cfg.disconnectOnBlocked; }
    public static void setDisconnectOnBlocked(boolean v) { cfg.disconnectOnBlocked = v; save(); }
    public static boolean allowSingleplayer() { return cfg.allowSingleplayer; }
    public static void setAllowSingleplayer(boolean v) { cfg.allowSingleplayer = v; save(); }
    public static List<String> hosts() { return new ArrayList<>(cfg.allowedHosts); }

    public static boolean isHardBlocked(String address) {
        String host = hostOf(address);
        for (String b : HARD_BLOCK) if (host.contains(b)) return true;
        return false;
    }

    /** @return null on success, otherwise a short reason. */
    public static String addHost(String address) {
        String h = hostOf(address);
        if (h.isEmpty()) return "Enter a server address";
        if (isHardBlocked(h)) return "That server is hard-blocked";
        for (String e : cfg.allowedHosts) if (hostOf(e).equals(h)) return "Already in the list";
        cfg.allowedHosts.add(h);
        save();
        return null;
    }

    public static void removeHost(String host) {
        cfg.allowedHosts.remove(host);
        save();
    }

    public static String hostOf(String address) {
        if (address == null) return "";
        String h = address.trim().toLowerCase(Locale.ROOT);
        if (h.startsWith("[")) { // [::1]:25565
            int end = h.indexOf(']');
            return end > 0 ? h.substring(1, end) : h;
        }
        int colon = h.lastIndexOf(':');
        if (colon > 0 && h.indexOf(':') == colon) h = h.substring(0, colon);
        return h;
    }

    public static boolean hostAllowed(String address) {
        String host = hostOf(address);
        if (host.isEmpty()) return false;
        for (String b : HARD_BLOCK) if (host.contains(b)) return false;
        for (String a : cfg.allowedHosts) {
            String entry = hostOf(a);
            if (entry.isEmpty()) continue;
            if (host.equals(entry) || host.endsWith("." + entry)) return true;
        }
        return false;
    }

    /** Address of the server we're on, or "" in singleplayer / menu. */
    public static String currentAddress(MinecraftClient mc) {
        if (mc == null || mc.isInSingleplayer()) return "";
        ServerInfo info = mc.getCurrentServerEntry();
        return info == null ? "" : info.address;
    }

    /** True when it is safe to run test modules right now. */
    public static boolean allowed(MinecraftClient mc) {
        if (mc == null || mc.player == null || mc.world == null) return false;
        if (mc.isInSingleplayer()) return cfg.allowSingleplayer;
        ServerInfo info = mc.getCurrentServerEntry();
        return info != null && hostAllowed(info.address);
    }
}
