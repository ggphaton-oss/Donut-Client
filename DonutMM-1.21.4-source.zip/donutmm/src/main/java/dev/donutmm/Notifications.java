package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Slide-in popups, bottom right, with a shrinking timer bar. */
public final class Notifications {
    private Notifications() {}

    private record Note(String title, String msg, int color, long born) {}

    private static final List<Note> LIST = new ArrayList<>();
    private static final float LIFE = 2.8f, IN = 0.30f, OUT = 0.35f;
    private static final int W = 156, H = 28;

    public static void push(String title, String msg, int rgb) {
        if (Modules.theme != null && !Modules.theme.notifications.value) return;
        if (LIST.size() >= 5) LIST.remove(0);
        LIST.add(new Note(title, msg, rgb, System.nanoTime()));
    }

    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        long now = System.nanoTime();
        LIST.removeIf(x -> (now - x.born) / 1e9f > LIFE);
        int n = LIST.size();
        for (int i = 0; i < n; i++) {
            Note note = LIST.get(n - 1 - i); // newest at the bottom
            float age = (now - note.born) / 1e9f;
            float vis = Math.min(Gfx.ease(age / IN), Gfx.ease((LIFE - age) / OUT));
            int x = sw - W - 8 + Math.round((1f - vis) * (W + 16));
            int y = sh - 38 - (i + 1) * (H + 6);
            Gfx.rrect(c, x - 1, y - 1, W + 2, H + 2, 6, Gfx.col(note.color, 0.30f * vis));
            Gfx.rrect(c, x, y, W, H, 5, Gfx.col(Gfx.BG, 0.94f * vis));
            Gfx.rrect(c, x + 5, y + 6, 3, H - 12, 1, Gfx.col(note.color, vis));
            Gfx.text(c, note.title, x + 14, y + 5, Gfx.TEXT, vis);
            Gfx.text(c, note.msg, x + 14, y + 16, Gfx.DIM, vis);
            float remain = Gfx.clamp(1f - age / LIFE, 0, 1);
            c.fill(x + 6, y + H - 3, x + 6 + Math.round((W - 12) * remain), y + H - 2, Gfx.col(note.color, 0.8f * vis));
        }
    }
}
