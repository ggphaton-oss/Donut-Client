package dev.donutmm;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class DonutMM implements ClientModInitializer {
    public static final String ID = "donutmm";
    private boolean prevKey, warned;

    @Override
    public void onInitializeClient() {
        ServerLock.load();
        Modules.loadConfig();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // Join check: leave immediately if the server isn't on the allow list.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (ServerLock.allowed(client)) {
                warned = false;
                Notifications.push("DonutMM", "Right Shift opens the menu", Gfx.accent());
            } else if (ServerLock.disconnectOnBlocked()) {
                client.execute(() -> handler.getConnection().disconnect(
                        Text.literal("DonutMM: this server is not allowed. Add it in the Server Lock tab (or config/donutmm.json).")));
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> Modules.disableAll());

        HudRenderCallback.EVENT.register(Hud::render);
        WorldRenderEvents.LAST.register(Modules::render3D);

        // Criticals hooks every attack (manual clicks and other modules).
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && ServerLock.allowed(MinecraftClient.getInstance())) CombatMods.onAttack(player, entity);
            return ActionResult.PASS;
        });
    }

    private void tick(MinecraftClient mc) {
        // Right Shift opens the GUI (polled, so no keybind registration needed)
        long win = mc.getWindow().getHandle();
        boolean down = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !prevKey && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
        prevKey = down;

        if (mc.player == null) return;

        if (!ServerLock.allowed(mc)) {
            if (Modules.anyEnabled()) Modules.disableAll();
            if (!warned && mc.world != null && !mc.isInSingleplayer()) {
                warned = true;
                Notifications.push("Locked", "Server not allowed, modules off", Gfx.RED);
            }
            return;
        }
        warned = false;
        Modules.pollBinds(mc);
        Modules.tick(mc);
    }
}
