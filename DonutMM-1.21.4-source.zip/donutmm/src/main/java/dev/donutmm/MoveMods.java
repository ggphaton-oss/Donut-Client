package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Movement test modules. Every value is adjustable so you can sit just above / below your own thresholds. */
final class MoveMods {
    private MoveMods() {}

    static void register(List<Module> l) {
        l.add(new Speed()); l.add(new Fly()); l.add(new NoFall()); l.add(new Step()); l.add(new Timer());
        l.add(new Jesus()); l.add(new Phase()); l.add(new Spider()); l.add(new HighJump()); l.add(new AirJump());
        l.add(new Sprint()); l.add(new AutoWalk());
    }

    static final class Speed extends Module {
        final Mode mode = mode("Mode", "Set", "Set", "Bhop", "Strafe", "Multiply", "OnGround");
        final Num speed = num("Speed (b/tick)", 0.10, 2.00, 0.01, 0.40);
        final Num mult = num("Multiplier", 1.0, 3.0, 0.05, 1.3).when(() -> mode.is("Multiply"));
        final Num airSpeed = num("Air speed (b/tick)", 0.10, 2.00, 0.01, 0.35).when(() -> mode.is("Bhop") || mode.is("Strafe"));
        final Bool air = bool("Apply in air", true).when(() -> mode.is("Set"));
        final Num jump = num("Hop height", 0.2, 0.8, 0.02, 0.42).when(() -> mode.is("Bhop"));
        final Bool sprintOnly = bool("Only while sprinting", false);
        final Bool stopOnRelease = bool("Stop when keys released", false);

        Speed() { super("Speed", "Horizontal speed override", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.isInsideWall() || p.hasVehicle()) return;
            double[] d = Modules.moveDir(mc, p);
            Vec3d v = p.getVelocity();
            if (d == null) {
                if (stopOnRelease.value && !mode.is("Multiply")) p.setVelocity(0, v.y, 0);
                return;
            }
            if (sprintOnly.value && !p.isSprinting()) return;
            switch (mode.get()) {
                case "Set" -> { if (air.value || p.isOnGround()) p.setVelocity(d[0] * speed.value, v.y, d[1] * speed.value); }
                case "OnGround" -> { if (p.isOnGround()) p.setVelocity(d[0] * speed.value, v.y, d[1] * speed.value); }
                case "Multiply" -> p.setVelocity(v.x * mult.value, v.y, v.z * mult.value);
                case "Bhop" -> {
                    if (p.isOnGround()) { p.setVelocity(d[0] * speed.value, jump.value, d[1] * speed.value); }
                    else p.setVelocity(d[0] * airSpeed.value, v.y, d[1] * airSpeed.value);
                }
                case "Strafe" -> {
                    double cur = Math.sqrt(v.x * v.x + v.z * v.z);
                    double s = p.isOnGround() ? speed.value : Math.max(cur, airSpeed.value);
                    p.setVelocity(d[0] * s, v.y, d[1] * s);
                }
            }
        }
    }

    static final class Fly extends Module {
        final Mode mode = mode("Mode", "Velocity", "Velocity", "Abilities", "Glide", "Jetpack");
        final Num horizontal = num("Horizontal", 0.05, 3.00, 0.05, 0.50);
        final Num vertical = num("Vertical", 0.05, 3.00, 0.05, 0.40).when(() -> !mode.is("Glide"));
        final Num glide = num("Fall speed", 0.0, 0.5, 0.01, 0.05).when(() -> mode.is("Glide"));
        final Num abilitySpeed = num("Ability fly speed", 0.01, 1.0, 0.01, 0.10).when(() -> mode.is("Abilities"));
        final Bool antiKick = bool("Anti-kick dip", false).when(() -> mode.is("Velocity"));
        final Num dipEvery = num("Dip every (ticks)", 10, 80, 1, 30).when(() -> mode.is("Velocity") && antiKick.value);
        private int tick;

        Fly() { super("Fly", "Free flight (jump up, sneak down)", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            double[] d = Modules.moveDir(mc, p);
            double vx = d == null ? 0 : d[0] * horizontal.value;
            double vz = d == null ? 0 : d[1] * horizontal.value;
            boolean up = mc.options.jumpKey.isPressed(), down = mc.options.sneakKey.isPressed();
            switch (mode.get()) {
                case "Velocity" -> {
                    double vy = up ? vertical.value : down ? -vertical.value : 0;
                    if (antiKick.value && !up && !down && ++tick % (int) dipEvery.value == 0) vy = -0.04;
                    p.setVelocity(vx, vy, vz);
                }
                case "Glide" -> p.setVelocity(vx, up ? 0.3 : -glide.value, vz);
                case "Jetpack" -> {
                    Vec3d v = p.getVelocity();
                    p.setVelocity(vx, up ? Math.min(v.y + vertical.value * 0.2, vertical.value * 1.5) : v.y, vz);
                }
                case "Abilities" -> {
                    p.getAbilities().allowFlying = true;
                    p.getAbilities().flying = true;
                    p.getAbilities().setFlySpeed((float) abilitySpeed.value);
                }
            }
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null && !p.isCreative() && !p.isSpectator()) {
                p.getAbilities().allowFlying = false;
                p.getAbilities().flying = false;
                p.getAbilities().setFlySpeed(0.05f);
            }
        }
    }

    static final class NoFall extends Module {
        final Mode mode = mode("Mode", "Packet", "Packet", "Always");
        final Num distance = num("Trigger distance", 0.5, 10.0, 0.5, 2.5).when(() -> mode.is("Packet"));
        final Bool resetFall = bool("Reset fall distance", false);

        NoFall() { super("NoFall", "Spoofs on-ground to skip fall damage", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.networkHandler == null || p.isOnGround()) return;
            boolean fire = mode.is("Always") ? p.getVelocity().y < 0 : p.fallDistance > distance.value;
            if (fire) p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
            if (fire && resetFall.value) p.fallDistance = 0;
        }
    }

    static final class Step extends Module {
        final Num height = num("Height", 0.6, 10.0, 0.1, 1.5);
        final Bool reverse = bool("Reverse step", false);
        final Num reverseH = num("Reverse distance", 0.5, 5.0, 0.1, 1.5).when(() -> reverse.value);
        final Num reverseSpeed = num("Reverse fall speed", 0.1, 3.0, 0.1, 1.0).when(() -> reverse.value);

        Step() { super("Step", "Raises step height", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            Modules.setAttr(p, EntityAttributes.STEP_HEIGHT, height.value);
            if (reverse.value && !p.isOnGround() && p.getVelocity().y <= 0 && !p.isTouchingWater()) {
                BlockPos bp = p.getBlockPos();
                for (int i = 1; i <= (int) Math.ceil(reverseH.value); i++) {
                    if (!mc.world.getBlockState(bp.down(i)).isAir()) { p.setVelocity(p.getVelocity().x, -reverseSpeed.value, p.getVelocity().z); break; }
                }
            }
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) Modules.setAttr(p, EntityAttributes.STEP_HEIGHT, 0.6);
        }
    }

    /** Sends extra movement packets each tick so the server sees more than 20 per second (tests Timer checks). */
    static final class Timer extends Module {
        final Num extra = num("Extra packets / tick", 1, 20, 1, 1);
        final Num every = num("Every N ticks", 1, 20, 1, 1);
        final Bool movingOnly = bool("Only while moving", true);
        final Num jitter = num("Rotation jitter (deg)", 0.0, 2.0, 0.05, 0.10);
        private int tick;

        Timer() { super("Timer", "Sends extra move packets (packet timer)", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.networkHandler == null || ++tick % (int) every.value != 0) return;
            if (movingOnly.value && Modules.moveDir(mc, p) == null) return;
            for (int i = 0; i < (int) extra.value; i++) {
                float j = (float) (jitter.value * (i % 2 == 0 ? 1 : -1));
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(p.getX(), p.getY(), p.getZ(),
                        p.getYaw() + j, p.getPitch(), p.isOnGround(), p.horizontalCollision));
            }
        }
    }

    static final class Jesus extends Module {
        final Mode mode = mode("Mode", "Solid", "Solid", "Dolphin", "Bob");
        final Num lift = num("Lift speed", 0.02, 0.6, 0.01, 0.11);
        final Bool lava = bool("Lava too", false);
        final Bool sneakSinks = bool("Sneak to sink", true);

        Jesus() { super("Jesus", "Walk on water", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            boolean inFluid = p.isTouchingWater() || (lava.value && p.isInLava());
            if (!inFluid) return;
            if (sneakSinks.value && mc.options.sneakKey.isPressed()) return;
            Vec3d v = p.getVelocity();
            switch (mode.get()) {
                case "Solid" -> p.setVelocity(v.x, lift.value, v.z);
                case "Dolphin" -> p.setVelocity(v.x, mc.options.jumpKey.isPressed() ? 0.3 : lift.value * 0.5, v.z);
                case "Bob" -> p.setVelocity(v.x, ((p.age & 3) < 2) ? lift.value : -lift.value * 0.5, v.z);
            }
        }
    }

    static final class Phase extends Module {
        final Bool hover = bool("Hover (no gravity)", false);
        final Num vspeed = num("Vertical speed", 0.05, 1.0, 0.05, 0.25).when(() -> hover.value);
        final Bool onlyInBlock = bool("Only while inside blocks", false);

        Phase() { super("Phase", "Walk through blocks (client noclip)", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            p.noClip = !onlyInBlock.value || p.isInsideWall();
            if (hover.value && p.noClip) {
                Vec3d v = p.getVelocity();
                double vy = mc.options.jumpKey.isPressed() ? vspeed.value : mc.options.sneakKey.isPressed() ? -vspeed.value : 0;
                p.setVelocity(v.x, vy, v.z);
            }
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) p.noClip = false;
        }
    }

    static final class Spider extends Module {
        final Num speed = num("Climb speed", 0.05, 1.0, 0.01, 0.2);

        Spider() { super("Spider", "Climb walls", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.horizontalCollision) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, speed.value, v.z); }
        }
    }

    static final class HighJump extends Module {
        final Num height = num("Jump velocity", 0.42, 3.0, 0.02, 0.9);

        HighJump() { super("HighJump", "Higher jumps", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.isOnGround() && mc.options.jumpKey.isPressed()) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, height.value, v.z); }
        }
    }

    static final class AirJump extends Module {
        final Num height = num("Jump velocity", 0.2, 1.5, 0.02, 0.42);
        final Num max = num("Max air jumps (0 = infinite)", 0, 10, 1, 0);
        final Num cooldown = num("Cooldown (ticks)", 0, 20, 1, 4);
        private boolean prev;
        private int used, cd;

        AirJump() { super("AirJump", "Jump again while in the air", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            boolean j = mc.options.jumpKey.isPressed();
            if (p.isOnGround()) used = 0;
            if (cd > 0) cd--;
            if (j && !prev && !p.isOnGround() && cd == 0 && (max.value == 0 || used < max.value)) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, height.value, v.z);
                used++;
                cd = (int) cooldown.value;
            }
            prev = j;
        }
    }

    static final class Sprint extends Module {
        final Bool omni = bool("All directions", false);
        final Bool whileSneaking = bool("Even while sneaking", false);

        Sprint() { super("Sprint", "Always sprint", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.getHungerManager().getFoodLevel() <= 6 && !p.isCreative()) return;
            if (!whileSneaking.value && p.isSneaking()) return;
            boolean fwd = mc.options.forwardKey.isPressed();
            boolean any = Modules.moveDir(mc, p) != null;
            if (omni.value ? any : fwd) p.setSprinting(true);
        }
    }

    static final class AutoWalk extends Module {
        final Bool jump = bool("Jump if blocked", true);

        AutoWalk() { super("AutoWalk", "Holds the forward key", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            mc.options.forwardKey.setPressed(true);
            if (jump.value && p.horizontalCollision && p.isOnGround()) p.jump();
        }

        @Override public void onDisable() { MinecraftClient.getInstance().options.forwardKey.setPressed(false); }
    }
}
