package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

public abstract class Module {
    public enum Category {
        MOVEMENT("Movement", Gfx.BLUE2), COMBAT("Combat", Gfx.TAN), WORLD("World", 0xC792EA),
        RENDER("Render", Gfx.GREEN), MISC("Misc", 0xF0C674), CLIENT("Client", 0x9AA5C8);
        public final String label;
        public final int color;
        Category(String label, int color) { this.label = label; this.color = color; }
    }

    // ------------------------------------------------------------------ settings

    public abstract static class Setting {
        public final String key, shown;
        /** Indented sub-setting (belongs to the colour row above it). */
        public boolean sub;
        private BooleanSupplier cond = () -> true;

        protected Setting(String key, String shown) { this.key = key; this.shown = shown; }

        public boolean visible() { return cond.getAsBoolean(); }
        public int height() { return 20; }

        /** Only show this setting while the condition holds. */
        @SuppressWarnings("unchecked")
        public <T extends Setting> T when(BooleanSupplier c) { this.cond = c; return (T) this; }

        abstract Object save();
        abstract void load(Object o);
    }

    public static final class Label extends Setting {
        Label(String name) { super("#" + name, name); }
        @Override public int height() { return 16; }
        @Override Object save() { return null; }
        @Override void load(Object o) {}
    }

    public static final class Bool extends Setting {
        public boolean value;
        public final Gfx.Anim anim;
        Bool(String key, String shown, boolean value) { super(key, shown); this.value = value; this.anim = new Gfx.Anim(value ? 1 : 0); }
        @Override Object save() { return value; }
        @Override void load(Object o) { if (o instanceof Boolean b) value = b; }
    }

    public static final class Num extends Setting {
        public final double min, max, step;
        public double value;
        public final int decimals;
        public final Gfx.Anim anim;
        Num(String key, String shown, double min, double max, double step, double value) {
            super(key, shown);
            this.min = min; this.max = max; this.step = step; this.value = value;
            this.decimals = step >= 1 ? 0 : (step >= 0.1 ? 1 : (step >= 0.01 ? 2 : 3));
            this.anim = new Gfx.Anim((float) ((value - min) / (max - min)));
        }
        @Override public int height() { return 28; }
        public String display() { return String.format(java.util.Locale.ROOT, "%." + decimals + "f", value); }
        public float ratio() { return (float) ((value - min) / (max - min)); }
        public float f() { return (float) value; }
        public int i() { return (int) Math.round(value); }
        @Override Object save() { return value; }
        @Override void load(Object o) { if (o instanceof Number n) value = Math.max(min, Math.min(max, n.doubleValue())); }
    }

    public static final class Mode extends Setting {
        public final String[] options;
        public int index;
        Mode(String key, String shown, String def, String... options) {
            super(key, shown);
            this.options = options;
            for (int i = 0; i < options.length; i++) if (options[i].equals(def)) index = i;
        }
        public String get() { return options[index]; }
        public boolean is(String s) { return options[index].equals(s); }
        public void next(int dir) { index = Math.floorMod(index + dir, options.length); }
        @Override Object save() { return get(); }
        @Override void load(Object o) { if (o instanceof String s) for (int i = 0; i < options.length; i++) if (options[i].equals(s)) index = i; }
    }

    /** A colour with optional animated rainbow. Click the row in the GUI to open its sub-settings. */
    public static final class ColorSet extends Setting {
        public boolean open;
        public final Num hue, sat, bri, speed, spread;
        public final Bool rainbow;

        ColorSet(String name, Num hue, Num sat, Num bri, Bool rainbow, Num speed, Num spread) {
            super("#color:" + name, name);
            this.hue = hue; this.sat = sat; this.bri = bri; this.rainbow = rainbow; this.speed = speed; this.spread = spread;
        }

        /** offset (any float) shifts the rainbow so lists / entities get different hues. */
        public int rgb(float offset) {
            float h;
            if (rainbow.value) h = (float) ((System.currentTimeMillis() / 1000.0) * speed.value * 0.15 + offset * spread.value);
            else h = (float) hue.value / 360f;
            return Gfx.hsb(h, (float) sat.value, (float) bri.value);
        }
        @Override Object save() { return null; }
        @Override void load(Object o) {}
    }

    // ------------------------------------------------------------------ module

    public final String name, description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();

    // GUI / HUD animation state
    public final Gfx.Anim guiOn = new Gfx.Anim(0), hudOn = new Gfx.Anim(0), hover = new Gfx.Anim(0), expand = new Gfx.Anim(0);
    public boolean expanded;

    /** GLFW key code, or -1. */
    public int bind = -1;
    boolean prevBind;
    /** Exempt from the server lock (HUD / Theme: purely cosmetic). */
    protected boolean exempt;
    /** Cannot be toggled and is hidden from the module list (Theme). */
    protected boolean permanent;
    /** Hidden from the HUD module list. */
    protected boolean hiddenInList;

    private boolean enabled;

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Label label(String n) { Label l = new Label(n); settings.add(l); return l; }
    protected Bool bool(String n, boolean d) { Bool b = new Bool(n, n, d); settings.add(b); return b; }
    protected Num num(String n, double min, double max, double step, double d) { Num x = new Num(n, n, min, max, step, d); settings.add(x); return x; }
    protected Mode mode(String n, String def, String... opts) { Mode m = new Mode(n, n, def, opts); settings.add(m); return m; }

    /** Adds a colour row plus Hue / Saturation / Brightness / Rainbow / Speed / Spread sub-settings. */
    protected ColorSet color(String n, double hueDeg, double sat, boolean rainbowDefault) {
        Num hue = new Num(n + ".hue", "Hue", 0, 360, 1, hueDeg);
        Num s = new Num(n + ".sat", "Saturation", 0, 1, 0.05, sat);
        Num b = new Num(n + ".bri", "Brightness", 0, 1, 0.05, 1.0);
        Bool rb = new Bool(n + ".rainbow", "Rainbow", rainbowDefault);
        Num sp = new Num(n + ".speed", "Rainbow speed", 0.1, 10, 0.1, 2.0);
        Num spr = new Num(n + ".spread", "Rainbow spread", 0, 2, 0.05, 0.5);
        ColorSet cs = new ColorSet(n, hue, s, b, rb, sp, spr);
        settings.add(cs);
        for (Setting x : new Setting[]{hue, s, b, rb, sp, spr}) { x.sub = true; x.when(() -> cs.open && cs.visible()); settings.add(x); }
        return cs;
    }

    public List<Setting> visibleSettings() {
        List<Setting> out = new ArrayList<>();
        for (Setting s : settings) if (s.visible()) out.add(s);
        return out;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { if (!permanent) setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (on && !exempt && !ServerLock.allowed(mc)) {
            Notifications.push("Locked", "Join singleplayer or an allowed server", Gfx.RED);
            return;
        }
        enabled = on;
        if (on) onEnable(); else onDisable();
        if (!exempt) Notifications.push(name, on ? "Enabled" : "Disabled", on ? Gfx.GREEN : Gfx.DIM);
    }

    /** Silent enable used when loading the config (exempt modules only). */
    void loadEnabled(boolean on) { if (exempt && on != enabled) { enabled = on; if (on) onEnable(); else onDisable(); } }

    /** Turn off without popup (used by the lock and on disconnect). */
    public void forceOff() {
        if (!enabled || exempt) return;
        enabled = false;
        onDisable();
    }

    // ---------------------------------------------------------------- persistence

    Map<String, Object> save() {
        Map<String, Object> m = new LinkedHashMap<>();
        for (Setting s : settings) { Object v = s.save(); if (v != null) m.put(s.key, v); }
        m.put("_bind", (double) bind);
        if (exempt) m.put("_enabled", enabled);
        return m;
    }

    @SuppressWarnings("unchecked")
    void load(Map<String, Object> m) {
        if (m == null) return;
        for (Setting s : settings) if (m.containsKey(s.key)) s.load(m.get(s.key));
        if (m.get("_bind") instanceof Number n) bind = n.intValue();
        if (m.get("_enabled") instanceof Boolean b) loadEnabled(b);
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {}
    /** Called every frame from the world-render hook (only while enabled). Draw with Render3D. */
    public void onRender3D(MinecraftClient mc, ClientPlayerEntity p) {}
}
