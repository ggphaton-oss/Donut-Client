package dev.donutmm;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Render test modules. ESP / StorageESP / BlockESP are drawn by Render3D (quads), so every colour can be rainbow. */
final class RenderMods {
    private RenderMods() {}

    static void register(List<Module> l) {
        l.add(new Esp()); l.add(new StorageEsp()); l.add(new BlockEsp()); l.add(new Fullbright());
        l.add(new XRayModule()); l.add(new ChunkFinder());
    }

    /** Draws a box in the chosen style. */
    static void drawBox(Box b, int rgb, String style, float lineA, float fillA, double width, int cornerPct) {
        if (style.equals("Filled") || style.equals("Both")) Render3D.filled(b, Render3D.argb(rgb, fillA));
        if (style.equals("Outline") || style.equals("Both")) Render3D.outline(b, Render3D.argb(rgb, lineA), width);
        if (style.equals("Corners")) Render3D.corners(b, Render3D.argb(rgb, lineA), width, cornerPct / 100.0);
    }

    // ------------------------------------------------------------------ ESP

    static final class Esp extends Module {
        final Label l1 = label("Targets");
        final Bool players = bool("Players", true);
        final Bool hostile = bool("Hostile mobs", false);
        final Bool passive = bool("Passive mobs", false);
        final Bool items = bool("Dropped items", false);
        final Bool crystals = bool("End crystals", false);
        final Bool projectiles = bool("Projectiles", false);
        final Bool invisible = bool("Include invisible", true);
        final Num range = num("Range", 8, 256, 4, 96);

        final Label l2 = label("Style");
        final Mode style = mode("Style", "Outline", "Outline", "Filled", "Both", "Corners");
        final Num width = num("Line width (blocks)", 0.005, 0.1, 0.005, 0.02);
        final Bool scaleWidth = bool("Scale width with distance", true);
        final Num corner = num("Corner length %", 10, 50, 5, 25).when(() -> style.is("Corners"));
        final Num expand = num("Box expand", -0.1, 0.8, 0.05, 0.05);
        final Num lineAlpha = num("Outline opacity", 0.1, 1.0, 0.05, 1.0);
        final Num fillAlpha = num("Fill opacity", 0.05, 1.0, 0.05, 0.25).when(() -> style.is("Filled") || style.is("Both"));
        final Bool through = bool("Through walls", true);
        final Bool fade = bool("Fade with distance", false);

        final Label l3 = label("Colors");
        final Mode cmode = mode("Color mode", "Type", "Type", "Rainbow", "Health", "Distance");
        final ColorSet rainbow = color("Rainbow", 0, 0.85, true).when(() -> cmode.is("Rainbow"));
        final ColorSet cPlayer = color("Players", 200, 0.85, false).when(() -> cmode.is("Type"));
        final ColorSet cHostile = color("Hostile", 0, 0.85, false).when(() -> cmode.is("Type"));
        final ColorSet cPassive = color("Passive", 120, 0.85, false).when(() -> cmode.is("Type"));
        final ColorSet cItem = color("Items", 50, 0.85, false).when(() -> cmode.is("Type"));
        final ColorSet cCrystal = color("Crystals", 300, 0.85, false).when(() -> cmode.is("Type"));
        final ColorSet cProj = color("Projectiles", 25, 0.85, false).when(() -> cmode.is("Type"));

        final Label l4 = label("Tracers");
        final Bool tracers = bool("Tracers", false);
        final Num tracerW = num("Tracer width (blocks)", 0.005, 0.1, 0.005, 0.02).when(() -> tracers.value);
        final Num tracerA = num("Tracer opacity", 0.1, 1.0, 0.05, 0.8).when(() -> tracers.value);
        final Mode tracerTo = mode("Tracer to", "Center", "Feet", "Center", "Eyes").when(() -> tracers.value);
        final Bool tracerPlayersOnly = bool("Tracers: players only", false).when(() -> tracers.value);

        Esp() { super("ESP", "Boxes / tracers through walls, rainbow capable", Category.RENDER); }

        @Override public void onRender3D(MinecraftClient mc, ClientPlayerEntity p) {
            Render3D.through(through.value);
            for (Entity e : mc.world.getEntities()) {
                if (e == p) continue;
                ColorSet cs;
                if (e instanceof PlayerEntity) { if (!players.value) continue; cs = cPlayer; }
                else if (e instanceof ItemEntity) { if (!items.value) continue; cs = cItem; }
                else if (e instanceof EndCrystalEntity) { if (!crystals.value) continue; cs = cCrystal; }
                else if (e instanceof ProjectileEntity) { if (!projectiles.value) continue; cs = cProj; }
                else if (e instanceof ArmorStandEntity || !(e instanceof LivingEntity)) continue;
                else if (e instanceof Monster) { if (!hostile.value) continue; cs = cHostile; }
                else if (e instanceof MobEntity) { if (!passive.value) continue; cs = cPassive; }
                else continue;
                if (!invisible.value && e.isInvisible()) continue;
                double dist = p.distanceTo(e);
                if (dist > range.value) continue;

                float off = e.getId() * 0.037f;
                int rgb = switch (cmode.get()) {
                    case "Rainbow" -> rainbow.rgb(off);
                    case "Health" -> e instanceof LivingEntity le
                            ? Gfx.hsb(MathHelper.clamp(le.getHealth() / Math.max(1f, le.getMaxHealth()), 0f, 1f) * 0.33f, 0.9f, 1f)
                            : cs.rgb(off);
                    case "Distance" -> Gfx.hsb(MathHelper.clamp((float) (dist / range.value), 0f, 1f) * 0.33f, 0.9f, 1f);
                    default -> cs.rgb(off);
                };
                float fa = fade.value ? (float) MathHelper.clamp(1.0 - dist / range.value * 0.8, 0.15, 1.0) : 1f;
                Box b = Render3D.lerpBox(e).expand(expand.value);
                double w = width.value * (scaleWidth.value ? Math.max(1.0, dist / 12.0) : 1.0);
                drawBox(b, rgb, style.get(), lineAlpha.f() * fa, fillAlpha.f() * fa, w, corner.i());

                if (tracers.value && (!tracerPlayersOnly.value || e instanceof PlayerEntity)) {
                    Vec3d to = switch (tracerTo.get()) {
                        case "Feet" -> new Vec3d((b.minX + b.maxX) / 2, b.minY, (b.minZ + b.maxZ) / 2);
                        case "Eyes" -> new Vec3d((b.minX + b.maxX) / 2, b.minY + (b.maxY - b.minY) * 0.9, (b.minZ + b.maxZ) / 2);
                        default -> b.getCenter();
                    };
                    int c = Render3D.argb(rgb, tracerA.f() * fa);
                    Render3D.line(Render3D.crosshair(), to, c, c, tracerW.value * (scaleWidth.value ? Math.max(1.0, dist / 12.0) : 1.0));
                }
            }
        }
    }

    // ------------------------------------------------------------------ StorageESP

    static final class StorageEsp extends Module {
        private record Hit(Box box, int type) {}
        static final String[] NAMES = {"Chest", "Trapped chest", "Ender chest", "Barrel", "Shulker box", "Spawner", "Furnace", "Hopper", "Dispenser/Dropper", "Other container"};

        final Label l1 = label("Containers");
        final Bool[] show = new Bool[NAMES.length];
        { for (int i = 0; i < NAMES.length; i++) show[i] = bool(NAMES[i], i != 6 && i != 7 && i != 8 && i != 9); }
        final Num range = num("Range", 8, 192, 4, 64);
        final Num interval = num("Refresh (ticks)", 2, 60, 1, 10);
        final Label l2 = label("Style");
        final Mode style = mode("Style", "Both", "Outline", "Filled", "Both", "Corners");
        final Num width = num("Line width (blocks)", 0.005, 0.1, 0.005, 0.02);
        final Num corner = num("Corner length %", 10, 50, 5, 25).when(() -> style.is("Corners"));
        final Num lineAlpha = num("Outline opacity", 0.1, 1.0, 0.05, 1.0);
        final Num fillAlpha = num("Fill opacity", 0.05, 1.0, 0.05, 0.2).when(() -> style.is("Filled") || style.is("Both"));
        final Bool through = bool("Through walls", true);
        final Bool tracers = bool("Tracers", false);
        final Num tracerW = num("Tracer width (blocks)", 0.005, 0.1, 0.005, 0.015).when(() -> tracers.value);
        final Label l3 = label("Colors");
        final Bool rainbowAll = bool("Rainbow override (all)", false);
        final ColorSet rainbow = color("Rainbow", 0, 0.85, true).when(() -> rainbowAll.value);
        final ColorSet[] colors = new ColorSet[NAMES.length];
        {
            double[] hue = {40, 25, 280, 30, 320, 190, 0, 210, 100, 60};
            for (int i = 0; i < NAMES.length; i++) { int k = i; colors[i] = color(NAMES[i] + " color", hue[i], 0.85, false).when(() -> !rainbowAll.value && show[k].value); }
        }
        private final List<Hit> hits = new ArrayList<>();
        private int tick;

        StorageEsp() { super("StorageESP", "Chests, barrels, spawners... with colours", Category.RENDER); }

        private static int typeOf(BlockEntity be) {
            if (be instanceof TrappedChestBlockEntity) return 1;
            if (be instanceof ChestBlockEntity) return 0;
            if (be instanceof EnderChestBlockEntity) return 2;
            if (be instanceof BarrelBlockEntity) return 3;
            if (be instanceof ShulkerBoxBlockEntity) return 4;
            if (be instanceof MobSpawnerBlockEntity) return 5;
            if (be instanceof AbstractFurnaceBlockEntity) return 6;
            if (be instanceof HopperBlockEntity) return 7;
            if (be instanceof DispenserBlockEntity) return 8;
            if (be instanceof LootableContainerBlockEntity) return 9;
            return -1;
        }

        @Override public void onDisable() { hits.clear(); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || tick++ % (int) interval.value != 0) return;
            hits.clear();
            int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
            int r = (int) Math.ceil(range.value / 16.0);
            double r2 = range.value * range.value;
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                Chunk ch = mc.world.getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                if (ch == null) continue;
                for (BlockPos bp : ch.getBlockEntityPositions()) {
                    if (Vec3d.ofCenter(bp).squaredDistanceTo(p.getPos()) > r2) continue;
                    BlockEntity be = mc.world.getBlockEntity(bp);
                    if (be == null) continue;
                    int t = typeOf(be);
                    if (t < 0 || !show[t].value) continue;
                    BlockState st = mc.world.getBlockState(bp);
                    VoxelShape sh = st.getOutlineShape(mc.world, bp);
                    Box b = sh.isEmpty() ? new Box(bp) : sh.getBoundingBox().offset(bp);
                    hits.add(new Hit(b, t));
                }
            }
        }

        @Override public void onRender3D(MinecraftClient mc, ClientPlayerEntity p) {
            Render3D.through(through.value);
            int i = 0;
            for (Hit h : hits) {
                float off = i++ * 0.05f;
                int rgb = rainbowAll.value ? rainbow.rgb(off) : colors[h.type].rgb(off);
                drawBox(h.box.expand(0.002), rgb, style.get(), lineAlpha.f(), fillAlpha.f(), width.value, corner.i());
                if (tracers.value) {
                    int c = Render3D.argb(rgb, 0.8f);
                    Render3D.line(Render3D.crosshair(), h.box.getCenter(), c, c, tracerW.value);
                }
            }
        }
    }

    // ------------------------------------------------------------------ BlockESP (ores)

    static final class BlockEsp extends Module {
        private record Hit(BlockPos pos, int kind) {}
        static final String[] NAMES = {"Diamond", "Ancient debris", "Emerald", "Gold", "Iron", "Coal", "Redstone", "Lapis", "Copper", "Nether quartz", "Nether gold"};
        static final double[] HUES = {185, 20, 130, 50, 25, 0, 0, 225, 15, 330, 45};

        final Label l1 = label("Blocks");
        final Bool[] show = new Bool[NAMES.length];
        { for (int i = 0; i < NAMES.length; i++) show[i] = bool(NAMES[i], i < 2); }
        final Label l2 = label("Scan");
        final Num range = num("Range (horizontal)", 6, 40, 2, 20);
        final Num vert = num("Range (vertical)", 4, 48, 2, 24);
        final Num interval = num("Rescan every (ticks)", 20, 200, 10, 40);
        final Num max = num("Max blocks drawn", 50, 2000, 50, 400);
        final Label l3 = label("Style");
        final Mode style = mode("Style", "Both", "Outline", "Filled", "Both", "Corners");
        final Num width = num("Line width (blocks)", 0.005, 0.1, 0.005, 0.02);
        final Num corner = num("Corner length %", 10, 50, 5, 25).when(() -> style.is("Corners"));
        final Num lineAlpha = num("Outline opacity", 0.1, 1.0, 0.05, 1.0);
        final Num fillAlpha = num("Fill opacity", 0.05, 1.0, 0.05, 0.25).when(() -> style.is("Filled") || style.is("Both"));
        final Bool through = bool("Through walls", true);
        final Bool tracers = bool("Tracers", false);
        final Label l4 = label("Colors");
        final Bool rainbowAll = bool("Rainbow override (all)", false);
        final ColorSet rainbow = color("Rainbow", 0, 0.85, true).when(() -> rainbowAll.value);
        final ColorSet[] colors = new ColorSet[NAMES.length];
        { for (int i = 0; i < NAMES.length; i++) { int k = i; colors[i] = color(NAMES[i] + " color", HUES[i], 0.85, false).when(() -> !rainbowAll.value && show[k].value); } }
        private final List<Hit> hits = new ArrayList<>();
        private final Map<Block, Integer> kinds = new HashMap<>();
        private int tick;

        BlockEsp() { super("BlockESP", "Highlights ores through walls", Category.RENDER); }

        private int kind(Block b) {
            return kinds.computeIfAbsent(b, bl -> {
                String p = Registries.BLOCK.getId(bl).getPath();
                if (p.endsWith("diamond_ore")) return 0;
                if (p.equals("ancient_debris")) return 1;
                if (p.endsWith("emerald_ore")) return 2;
                if (p.equals("nether_gold_ore")) return 10;
                if (p.endsWith("gold_ore")) return 3;
                if (p.endsWith("iron_ore")) return 4;
                if (p.endsWith("coal_ore")) return 5;
                if (p.endsWith("redstone_ore")) return 6;
                if (p.endsWith("lapis_ore")) return 7;
                if (p.endsWith("copper_ore")) return 8;
                if (p.equals("nether_quartz_ore")) return 9;
                return -1;
            });
        }

        @Override public void onDisable() { hits.clear(); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || tick++ % (int) interval.value != 0) return;
            hits.clear();
            BlockPos c = p.getBlockPos();
            int r = (int) range.value, v = (int) vert.value;
            int y0 = Math.max(mc.world.getBottomY(), c.getY() - v), y1 = Math.min(mc.world.getTopY() - 1, c.getY() + v);
            BlockPos.Mutable mp = new BlockPos.Mutable();
            for (int x = c.getX() - r; x <= c.getX() + r; x++) for (int z = c.getZ() - r; z <= c.getZ() + r; z++) {
                if (mc.world.getChunk(x >> 4, z >> 4, ChunkStatus.FULL, false) == null) continue;
                for (int y = y0; y <= y1; y++) {
                    mp.set(x, y, z);
                    BlockState st = mc.world.getBlockState(mp);
                    if (st.isAir()) continue;
                    int k = kind(st.getBlock());
                    if (k < 0 || !show[k].value) continue;
                    hits.add(new Hit(mp.toImmutable(), k));
                    if (hits.size() >= (int) max.value) return;
                }
            }
        }

        @Override public void onRender3D(MinecraftClient mc, ClientPlayerEntity p) {
            Render3D.through(through.value);
            int i = 0;
            for (Hit h : hits) {
                float off = i++ * 0.02f;
                int rgb = rainbowAll.value ? rainbow.rgb(off) : colors[h.kind].rgb(off);
                drawBox(new Box(h.pos).expand(0.002), rgb, style.get(), lineAlpha.f(), fillAlpha.f(), width.value, corner.i());
                if (tracers.value) {
                    int c = Render3D.argb(rgb, 0.7f);
                    Render3D.line(Render3D.crosshair(), Vec3d.ofCenter(h.pos), c, c, 0.015);
                }
            }
        }
    }

    // ------------------------------------------------------------------ simple ones

    static final class Fullbright extends Module {
        Fullbright() { super("Fullbright", "Max brightness (night vision)", Category.RENDER); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
            }
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    /** X-Ray: hides every block face except the selected groups. Needs vanilla chunk rendering (no Sodium). */
    static final class XRayModule extends Module {
        final Mode ores = mode("Ores", "All ores", "Off", "All ores", "Valuable only", "Diamond only");
        final Bool debris = bool("Ancient debris", true);
        final Bool containers = bool("Chests / barrels / shulkers", true);
        final Bool spawners = bool("Spawners", true);
        private int last = -1;

        XRayModule() { super("X-Ray", "Only selected blocks visible, pair with Fullbright", Category.RENDER); }

        private int mask() {
            int m = 0;
            switch (ores.get()) {
                case "All ores" -> m |= XRay.ORE;
                case "Valuable only" -> m |= XRay.VALUABLE;
                case "Diamond only" -> m |= XRay.DIAMOND;
                default -> {}
            }
            if (debris.value) m |= XRay.DEBRIS;
            if (containers.value) m |= XRay.CONTAINER;
            if (spawners.value) m |= XRay.SPAWNER;
            return m;
        }

        @Override public void onEnable() { last = mask(); XRay.mask = last; XRay.active = true; reload(); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            int m = mask();
            if (m != last) { last = m; XRay.mask = m; reload(); }
        }

        @Override public void onDisable() { XRay.active = false; reload(); }

        private static void reload() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.worldRenderer != null) mc.worldRenderer.reload();
        }
    }

    /** Lists loaded chunks with lots of containers (HUD panel). Uses block entity data the server already sent. */
    static final class ChunkFinder extends Module {
        static final List<String> LINES = new ArrayList<>();
        final Num radius = num("Radius (chunks)", 4, 32, 1, 12);
        final Num min = num("Min containers", 1, 50, 1, 8);
        final Num top = num("Show top", 1, 10, 1, 5);
        final Num refresh = num("Refresh (ticks)", 10, 200, 10, 40);
        final Bool spawnersCount = bool("Count spawners (x5)", true);
        private int tick;

        ChunkFinder() { super("ChunkFinder", "Chunks with many containers", Category.RENDER); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (tick++ % (int) refresh.value != 0 || mc.world == null) return;
            int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
            int r = (int) radius.value;
            List<int[]> found = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    Chunk ch = mc.world.getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                    if (ch == null) continue;
                    int cont = 0, spw = 0;
                    for (BlockPos bp : ch.getBlockEntityPositions()) {
                        BlockEntity be = mc.world.getBlockEntity(bp);
                        if (be instanceof LootableContainerBlockEntity) cont++;
                        else if (be instanceof MobSpawnerBlockEntity) spw++;
                    }
                    if (cont >= min.value || spw > 0) found.add(new int[]{pcx + dx, pcz + dz, cont, spw});
                }
            }
            int sw = spawnersCount.value ? 5 : 0;
            found.sort((a, b) -> Integer.compare(b[2] + b[3] * sw, a[2] + a[3] * sw));
            LINES.clear();
            for (int i = 0; i < Math.min(found.size(), (int) top.value); i++) {
                int[] h = found.get(i);
                int bx = h[0] * 16 + 8, bz = h[1] * 16 + 8;
                int dist = (int) Math.sqrt(Math.pow(bx - p.getX(), 2) + Math.pow(bz - p.getZ(), 2));
                LINES.add(bx + ", " + bz + "  " + h[2] + " cont" + (h[3] > 0 ? " +" + h[3] + " spw" : "") + "  " + dist + "m");
            }
        }

        @Override public void onDisable() { LINES.clear(); }
    }
}
