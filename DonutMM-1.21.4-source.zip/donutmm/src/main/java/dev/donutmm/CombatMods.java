package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Combat test modules. */
final class CombatMods {
    private CombatMods() {}

    static void register(List<Module> l) {
        l.add(new KillAura()); l.add(new Reach()); l.add(new HitBox()); l.add(new Criticals());
        l.add(new AutoClicker()); l.add(new Triggerbot()); l.add(new AimAssist()); l.add(new AutoTotem());
    }

    static boolean valid(Entity e, ClientPlayerEntity p, boolean players, boolean hostile, boolean passive, boolean invisible) {
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || le.isSpectator() || e instanceof ArmorStandEntity) return false;
        if (!invisible && le.isInvisible()) return false;
        if (e instanceof PlayerEntity) return players;
        if (e instanceof Monster) return hostile;
        if (e instanceof MobEntity) return passive;
        return false;
    }

    static boolean holdingWeapon(ClientPlayerEntity p) {
        var s = p.getMainHandStack();
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    static boolean chance(double pct) { return pct >= 100 || ThreadLocalRandom.current().nextDouble() * 100 < pct; }

    static double gap(double cpsMin, double cpsMax, String style) {
        double cps = switch (style) {
            case "Constant" -> cpsMax;
            case "Gaussian" -> MathHelper.clamp((cpsMin + cpsMax) / 2 + ThreadLocalRandom.current().nextGaussian() * (cpsMax - cpsMin) / 4, cpsMin, cpsMax);
            default -> cpsMin + ThreadLocalRandom.current().nextDouble() * (cpsMax - cpsMin);
        };
        return 1e9 / Math.max(0.5, cps);
    }

    /** Called from the AttackEntityCallback for every attack (manual or module). */
    static void onAttack(PlayerEntity pl, Entity target) {
        for (Module m : Modules.ALL) if (m instanceof Criticals c && c.isEnabled()) c.fire(pl);
    }

    // ------------------------------------------------------------------ KillAura

    static final class KillAura extends Module {
        final Label t = label("Targets");
        final Bool players = bool("Players", true);
        final Bool hostile = bool("Hostile mobs", false);
        final Bool passive = bool("Passive mobs", false);
        final Bool invisible = bool("Invisible", true);
        final Label a = label("Attack");
        final Mode priority = mode("Priority", "Distance", "Distance", "Health", "Angle");
        final Num range = num("Range", 2.5, 8.0, 0.1, 4.0);
        final Num cpsMin = num("CPS min", 1, 20, 1, 8);
        final Num cpsMax = num("CPS max", 1, 20, 1, 12);
        final Mode style = mode("CPS style", "Uniform", "Uniform", "Gaussian", "Constant");
        final Bool cooldown = bool("Wait for cooldown", false);
        final Num hitChance = num("Hit chance %", 1, 100, 1, 100);
        final Bool multi = bool("Multi target", false);
        final Num maxTargets = num("Max targets", 2, 8, 1, 3).when(() -> multi.value);
        final Bool weaponOnly = bool("Only holding weapon", false);
        final Bool swing = bool("Swing hand", true);
        final Label r = label("Rotation");
        final Mode rotate = mode("Rotation", "Snap", "Snap", "Smooth", "None");
        final Num smooth = num("Smooth factor", 0.05, 1.0, 0.05, 0.35).when(() -> rotate.is("Smooth"));
        final Num aimTol = num("Attack when aim within (deg)", 1, 90, 1, 12).when(() -> rotate.is("Smooth"));
        final Num fov = num("FOV (deg, 360 = all)", 30, 360, 5, 360);
        final Bool walls = bool("Through walls", true);
        private long next;

        KillAura() { super("KillAura", "Auto-attacks targets around you", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (weaponOnly.value && !holdingWeapon(p)) return;
            long now = System.nanoTime();
            if (now < next) return;
            if (cooldown.value && p.getAttackCooldownProgress(0.5f) < 0.95f) return;

            List<LivingEntity> cands = new ArrayList<>();
            for (Entity e : mc.world.getEntities()) {
                if (!valid(e, p, players.value, hostile.value, passive.value, invisible.value)) continue;
                if (p.distanceTo(e) > range.value) continue;
                if (!walls.value && !p.canSee(e)) continue;
                Vec3d c = e.getBoundingBox().getCenter();
                float[] rt = Modules.rotsTo(p, c);
                float yawD = MathHelper.wrapDegrees(rt[0] - p.getYaw());
                if (fov.value < 360 && Math.abs(yawD) > fov.value / 2) continue;
                cands.add((LivingEntity) e);
            }
            if (cands.isEmpty()) return;
            cands.sort((x, y) -> switch (priority.get()) {
                case "Health" -> Float.compare(x.getHealth(), y.getHealth());
                case "Angle" -> Float.compare(angle(p, x), angle(p, y));
                default -> Float.compare(p.distanceTo(x), p.distanceTo(y));
            });

            LivingEntity first = cands.get(0);
            if (!rotate.is("None")) {
                float[] rt = Modules.rotsTo(p, first.getBoundingBox().getCenter());
                if (rotate.is("Snap")) { p.setYaw(rt[0]); p.setPitch(MathHelper.clamp(rt[1], -90f, 90f)); }
                else {
                    float dy = MathHelper.wrapDegrees(rt[0] - p.getYaw()), dp = rt[1] - p.getPitch();
                    p.setYaw(p.getYaw() + dy * smooth.f());
                    p.setPitch(MathHelper.clamp(p.getPitch() + dp * smooth.f(), -90f, 90f));
                    if (Math.sqrt(dy * dy + dp * dp) > aimTol.value) return;
                }
            }
            if (!chance(hitChance.value)) { next = now + (long) gap(cpsMin.value, cpsMax.value, style.get()); return; }
            int n = multi.value ? Math.min(cands.size(), (int) maxTargets.value) : 1;
            for (int i = 0; i < n; i++) mc.interactionManager.attackEntity(p, cands.get(i));
            if (swing.value) p.swingHand(Hand.MAIN_HAND);
            next = now + (long) gap(Math.min(cpsMin.value, cpsMax.value), Math.max(cpsMin.value, cpsMax.value), style.get());
        }

        private static float angle(ClientPlayerEntity p, Entity e) {
            float[] rt = Modules.rotsTo(p, e.getBoundingBox().getCenter());
            float dy = MathHelper.wrapDegrees(rt[0] - p.getYaw()), dp = rt[1] - p.getPitch();
            return (float) Math.sqrt(dy * dy + dp * dp);
        }
    }

    // ------------------------------------------------------------------ Reach / HitBox / Criticals

    static final class Reach extends Module {
        final Num entity = num("Entity reach", 3.0, 8.0, 0.05, 4.5);
        final Bool blocks = bool("Also blocks", false);
        final Num block = num("Block reach", 4.5, 10.0, 0.1, 6.0).when(() -> blocks.value);

        Reach() { super("Reach", "Extends interaction range", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            Modules.setAttr(p, EntityAttributes.ENTITY_INTERACTION_RANGE, entity.value);
            Modules.setAttr(p, EntityAttributes.BLOCK_INTERACTION_RANGE, blocks.value ? block.value : 4.5);
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p == null) return;
            Modules.setAttr(p, EntityAttributes.ENTITY_INTERACTION_RANGE, 3.0);
            Modules.setAttr(p, EntityAttributes.BLOCK_INTERACTION_RANGE, 4.5);
        }
    }

    /** Makes other entities easier to hit with the crosshair (mixin on Entity#getTargetingMargin). */
    static final class HitBox extends Module {
        final Num expand = num("Expand (blocks)", 0.0, 1.5, 0.05, 0.3);
        final Bool players = bool("Players", true);
        final Bool mobs = bool("Mobs", false);

        HitBox() { super("HitBox", "Bigger crosshair target on entities", Category.COMBAT); }

        float extra(Entity e) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || e == mc.player) return 0f;
            if (e instanceof PlayerEntity) return players.value ? expand.f() : 0f;
            if (e instanceof LivingEntity) return mobs.value ? expand.f() : 0f;
            return 0f;
        }
    }

    /** Sends the fake-jump packets before every attack (manual or from other modules). */
    static final class Criticals extends Module {
        final Mode mode = mode("Mode", "Packet", "Packet", "Mini", "Jump");
        final Bool onlyGround = bool("Only on ground", true);
        final Num delay = num("Min delay between (ms)", 0, 1000, 10, 0);
        private long last;

        Criticals() { super("Criticals", "Forces critical hits via packets", Category.COMBAT); }

        void fire(PlayerEntity pl) {
            if (!(pl instanceof ClientPlayerEntity p) || p.networkHandler == null) return;
            if (onlyGround.value && !p.isOnGround()) return;
            if (p.isTouchingWater() || p.isClimbing() || p.hasVehicle()) return;
            long now = System.currentTimeMillis();
            if (now - last < delay.value) return;
            last = now;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            switch (mode.get()) {
                case "Packet" -> {
                    p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, p.horizontalCollision));
                    p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, p.horizontalCollision));
                }
                case "Mini" -> {
                    p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.011, z, false, p.horizontalCollision));
                    p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.001, z, false, p.horizontalCollision));
                }
                case "Jump" -> p.jump();
            }
        }
    }

    // ------------------------------------------------------------------ clickers

    static final class AutoClicker extends Module {
        final Mode button = mode("Button", "Left", "Left", "Right", "Both");
        final Num cpsMin = num("CPS min", 1, 30, 1, 9);
        final Num cpsMax = num("CPS max", 1, 30, 1, 13);
        final Mode style = mode("Timing", "Uniform", "Uniform", "Gaussian", "Constant");
        final Bool holdOnly = bool("Only while button held", true);
        final Bool entityOnly = bool("Left: only when aiming at entity", true);
        final Bool inGui = bool("Click while a screen is open", false);
        final Num dropChance = num("Random missed clicks %", 0, 50, 1, 0);
        private long nextL, nextR;

        AutoClicker() { super("AutoClicker", "Clicks for you", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.interactionManager == null || (!inGui.value && mc.currentScreen != null)) return;
            long now = System.nanoTime();
            double lo = Math.min(cpsMin.value, cpsMax.value), hi = Math.max(cpsMin.value, cpsMax.value);
            if ((button.is("Left") || button.is("Both")) && now >= nextL
                    && (!holdOnly.value || mc.options.attackKey.isPressed())) {
                if (mc.crosshairTarget instanceof EntityHitResult hit) {
                    if (chance(100 - dropChance.value)) { mc.interactionManager.attackEntity(p, hit.getEntity()); p.swingHand(Hand.MAIN_HAND); }
                    nextL = now + (long) gap(lo, hi, style.get());
                } else if (!entityOnly.value) {
                    p.swingHand(Hand.MAIN_HAND);
                    nextL = now + (long) gap(lo, hi, style.get());
                }
            }
            if ((button.is("Right") || button.is("Both")) && now >= nextR
                    && (!holdOnly.value || mc.options.useKey.isPressed())) {
                if (chance(100 - dropChance.value)) {
                    if (mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, bhr);
                    else mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                    p.swingHand(Hand.MAIN_HAND);
                }
                nextR = now + (long) gap(lo, hi, style.get());
            }
        }
    }

    static final class Triggerbot extends Module {
        final Bool players = bool("Players", true);
        final Bool hostile = bool("Hostile mobs", false);
        final Bool passive = bool("Passive mobs", false);
        final Bool cooldown = bool("Wait for cooldown", true);
        final Bool weaponOnly = bool("Only holding weapon", false);
        final Bool critsOnly = bool("Only criticals (falling)", false);
        final Num hitChance = num("Hit chance %", 1, 100, 1, 100);
        final Num delayMin = num("Delay min (ms)", 0, 500, 10, 0);
        final Num delayMax = num("Delay max (ms)", 0, 500, 10, 60);
        private long next;

        Triggerbot() { super("Triggerbot", "Attacks when crosshair is on a target", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
            Entity e = hit.getEntity();
            if (!valid(e, p, players.value, hostile.value, passive.value, true)) return;
            if (weaponOnly.value && !holdingWeapon(p)) return;
            if (cooldown.value && p.getAttackCooldownProgress(0.5f) < 0.95f) return;
            if (critsOnly.value && (p.isOnGround() || p.fallDistance <= 0f)) return;
            long now = System.nanoTime();
            if (now < next) return;
            double lo = Math.min(delayMin.value, delayMax.value), hi = Math.max(delayMin.value, delayMax.value);
            next = now + (long) ((lo + ThreadLocalRandom.current().nextDouble() * (hi - lo)) * 1e6);
            if (!chance(hitChance.value)) return;
            mc.interactionManager.attackEntity(p, e);
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    static final class AimAssist extends Module {
        final Bool players = bool("Players", true);
        final Bool hostile = bool("Hostile mobs", false);
        final Bool passive = bool("Passive mobs", false);
        final Num range = num("Range", 2.5, 12.0, 0.1, 5.0);
        final Num fov = num("FOV (degrees)", 10, 360, 5, 60);
        final Num strength = num("Strength", 0.02, 1.0, 0.01, 0.30);
        final Num randomness = num("Randomness", 0.0, 1.0, 0.05, 0.15);
        final Bool vertical = bool("Vertical aim", true);
        final Bool walls = bool("Through walls", false);
        final Bool onlyAttack = bool("Only while attacking", true);
        final Bool weaponOnly = bool("Only holding weapon", false);
        final Mode aimAt = mode("Aim at", "Center", "Center", "Eyes", "Feet");

        AimAssist() { super("AimAssist", "Smoothly pulls aim toward targets", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || mc.currentScreen != null) return;
            if (onlyAttack.value && !mc.options.attackKey.isPressed()) return;
            if (weaponOnly.value && !holdingWeapon(p)) return;
            float bestAngle = (float) fov.value, bestYaw = 0, bestPitch = 0;
            boolean found = false;
            for (Entity e : mc.world.getEntities()) {
                if (!valid(e, p, players.value, hostile.value, passive.value, true)) continue;
                if (p.distanceTo(e) > range.value) continue;
                if (!walls.value && !p.canSee(e)) continue;
                Vec3d t = switch (aimAt.get()) {
                    case "Eyes" -> e.getEyePos();
                    case "Feet" -> e.getPos().add(0, 0.2, 0);
                    default -> e.getBoundingBox().getCenter();
                };
                float[] r = Modules.rotsTo(p, t);
                float dy = MathHelper.wrapDegrees(r[0] - p.getYaw()), dp = r[1] - p.getPitch();
                float ang = (float) Math.sqrt(dy * dy + dp * dp);
                if (ang <= bestAngle) { bestAngle = ang; bestYaw = dy; bestPitch = dp; found = true; }
            }
            if (!found) return;
            double j = 1.0 + (ThreadLocalRandom.current().nextDouble() * 2 - 1) * randomness.value;
            float s = (float) (strength.value * j);
            p.setYaw(p.getYaw() + bestYaw * s);
            if (vertical.value) p.setPitch(MathHelper.clamp(p.getPitch() + bestPitch * s, -90f, 90f));
        }
    }

    static final class AutoTotem extends Module {
        final Num delay = num("Delay (ticks)", 0, 10, 1, 1);
        final Num health = num("Only below health (20 = always)", 1, 20, 1, 20);
        final Bool whileGui = bool("Work with inventory open", false);
        private int idle;

        AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if ((!whileGui.value && mc.currentScreen != null) || mc.interactionManager == null) return;
            if (p.getHealth() + p.getAbsorptionAmount() > health.value && health.value < 20) return;
            if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) { idle = 0; return; }
            if (idle++ < delay.value) return;
            for (int i = 0; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                    idle = 0;
                    return;
                }
            }
        }
    }
}
