package dev.donutmm.mixin;

import dev.donutmm.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** HitBox module: grows the targeting margin of other entities (crosshair/raycast only, not the real hitbox). */
@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
    private void donutmm$hitbox(CallbackInfoReturnable<Float> cir) {
        float extra = Modules.hitboxExpand((Entity) (Object) this);
        if (extra > 0f) cir.setReturnValue(cir.getReturnValueF() + extra);
    }
}
