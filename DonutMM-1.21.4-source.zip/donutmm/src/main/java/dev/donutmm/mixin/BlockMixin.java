package dev.donutmm.mixin;

import dev.donutmm.XRay;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true, require = 0)
    private static void donutmm$xray(BlockState state, BlockState neighbor, Direction side, CallbackInfoReturnable<Boolean> cir) {
        if (XRay.active) cir.setReturnValue(XRay.visible(state));
    }
}
