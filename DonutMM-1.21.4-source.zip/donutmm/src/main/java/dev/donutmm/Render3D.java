package dev.donutmm;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Tiny immediate-mode renderer for ESP style drawing. Everything is built out of coloured quads
 * (edges are thin cuboids, tracers are ribbons) so line-width support is not needed.
 * Shapes are collected during the frame and drawn once in {@link #end()}.
 */
public final class Render3D {
    private Render3D() {}

    private static final class Verts {
        float[] xyz = new float[3 * 4096];
        int[] col = new int[4096];
        int n;
        void add(double x, double y, double z, int argb) {
            if (n == col.length) {
                xyz = java.util.Arrays.copyOf(xyz, xyz.length * 2);
                col = java.util.Arrays.copyOf(col, col.length * 2);
            }
            xyz[n * 3] = (float) (x - cam.x);
            xyz[n * 3 + 1] = (float) (y - cam.y);
            xyz[n * 3 + 2] = (float) (z - cam.z);
            col[n++] = argb;
        }
    }

    public static Vec3d cam = Vec3d.ZERO;
    public static Vec3d look = new Vec3d(0, 0, 1);
    public static float delta = 1f;

    private static final Verts DEPTH = new Verts(), THROUGH = new Verts();
    private static Verts cur = DEPTH;
    private static Matrix4f mat;

    // ---------------------------------------------------------------- frame

    /** @return false if nothing can be drawn this frame. */
    static boolean begin(WorldRenderContext ctx) {
        MatrixStack ms = ctx.matrixStack();
        if (ms == null || ctx.camera() == null) return false;
        mat = new Matrix4f(ms.peek().getPositionMatrix());
        cam = ctx.camera().getPos();
        look = Vec3d.fromPolar(ctx.camera().getPitch(), ctx.camera().getYaw());
        delta = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(true);
        DEPTH.n = 0;
        THROUGH.n = 0;
        return true;
    }

    static void end() {
        if (DEPTH.n == 0 && THROUGH.n == 0) return;
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        flush(DEPTH, true);
        flush(THROUGH, false);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void flush(Verts v, boolean depth) {
        if (v.n == 0) return;
        if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < v.n; i++) b.vertex(mat, v.xyz[i * 3], v.xyz[i * 3 + 1], v.xyz[i * 3 + 2]).color(v.col[i]);
        BufferRenderer.drawWithGlobalProgram(b.end());
        v.n = 0;
    }

    /** Choose whether following shapes are hidden by walls (false) or drawn through them (true). */
    public static void through(boolean t) { cur = t ? THROUGH : DEPTH; }

    // ---------------------------------------------------------------- helpers

    public static int argb(int rgb, float alpha) {
        return (Math.round(MathHelper.clamp(alpha, 0f, 1f) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    private static void quad(double ax, double ay, double az, double bx, double by, double bz,
                             double cx, double cy, double cz, double dx, double dy, double dz, int c) {
        cur.add(ax, ay, az, c); cur.add(bx, by, bz, c); cur.add(cx, cy, cz, c); cur.add(dx, dy, dz, c);
    }

    public static void cuboid(double x0, double y0, double z0, double x1, double y1, double z1, int c) {
        quad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, c); // bottom
        quad(x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, c); // top
        quad(x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, c); // north
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, c); // south
        quad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, c); // west
        quad(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, c); // east
    }

    public static void filled(Box b, int argb) { cuboid(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, argb); }

    /** Box edges as thin cuboids, w = thickness in blocks. */
    public static void outline(Box b, int argb, double w) {
        double h = w / 2;
        double x0 = b.minX, y0 = b.minY, z0 = b.minZ, x1 = b.maxX, y1 = b.maxY, z1 = b.maxZ;
        for (double y : new double[]{y0, y1}) {
            cuboid(x0 - h, y - h, z0 - h, x1 + h, y + h, z0 + h, argb);
            cuboid(x0 - h, y - h, z1 - h, x1 + h, y + h, z1 + h, argb);
            cuboid(x0 - h, y - h, z0 - h, x0 + h, y + h, z1 + h, argb);
            cuboid(x1 - h, y - h, z0 - h, x1 + h, y + h, z1 + h, argb);
        }
        for (double x : new double[]{x0, x1}) for (double z : new double[]{z0, z1})
            cuboid(x - h, y0 - h, z - h, x + h, y1 + h, z + h, argb);
    }

    /** Only the corners of the box (frac = length of each corner arm as a fraction of the side). */
    public static void corners(Box b, int argb, double w, double frac) {
        double h = w / 2;
        double lx = (b.maxX - b.minX) * frac, ly = (b.maxY - b.minY) * frac, lz = (b.maxZ - b.minZ) * frac;
        for (int xi = 0; xi < 2; xi++) for (int yi = 0; yi < 2; yi++) for (int zi = 0; zi < 2; zi++) {
            double x = xi == 0 ? b.minX : b.maxX, y = yi == 0 ? b.minY : b.maxY, z = zi == 0 ? b.minZ : b.maxZ;
            double sx = xi == 0 ? 1 : -1, sy = yi == 0 ? 1 : -1, sz = zi == 0 ? 1 : -1;
            cuboid(Math.min(x, x + sx * lx) - h, y - h, z - h, Math.max(x, x + sx * lx) + h, y + h, z + h, argb);
            cuboid(x - h, Math.min(y, y + sy * ly) - h, z - h, x + h, Math.max(y, y + sy * ly) + h, z + h, argb);
            cuboid(x - h, y - h, Math.min(z, z + sz * lz) - h, x + h, y + h, Math.max(z, z + sz * lz) + h, argb);
        }
    }

    /** Camera-facing ribbon from a to b (w = width in blocks). */
    public static void line(Vec3d a, Vec3d b, int argbA, int argbB, double w) {
        Vec3d dir = b.subtract(a);
        Vec3d side = dir.crossProduct(look);
        if (side.lengthSquared() < 1e-9) return;
        side = side.normalize().multiply(w / 2);
        cur.add(a.x + side.x, a.y + side.y, a.z + side.z, argbA);
        cur.add(a.x - side.x, a.y - side.y, a.z - side.z, argbA);
        cur.add(b.x - side.x, b.y - side.y, b.z - side.z, argbB);
        cur.add(b.x + side.x, b.y + side.y, b.z + side.z, argbB);
    }

    /** Point just in front of the camera, where tracers start (the crosshair). */
    public static Vec3d crosshair() { return cam.add(look.multiply(0.6)); }

    /** Interpolated bounding box of an entity for smooth rendering. */
    public static Box lerpBox(net.minecraft.entity.Entity e) {
        double x = MathHelper.lerp(delta, e.prevX, e.getX()) - e.getX();
        double y = MathHelper.lerp(delta, e.prevY, e.getY()) - e.getY();
        double z = MathHelper.lerp(delta, e.prevZ, e.getZ()) - e.getZ();
        return e.getBoundingBox().offset(x, y, z);
    }
}
