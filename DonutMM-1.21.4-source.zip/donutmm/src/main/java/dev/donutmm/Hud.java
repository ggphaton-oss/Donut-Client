package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext c, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        boolean guiOpen = mc.currentScreen instanceof ClickGui;
        ClientMods.HudModule h = Modules.hud;

        if (h != null && h.isEnabled()) {
            int topY = 6;
            if (h.watermark.value) topY = watermark(c, mc, h) + 4;
            if (h.list.value) moduleList(c, mc, h);
            infoLines(c, mc, h, topY);
        }

        // Chunk finder panel
        if (!RenderMods.ChunkFinder.LINES.isEmpty()) {
            int pw = Gfx.w("Chunk finder");
            for (String l : RenderMods.ChunkFinder.LINES) pw = Math.max(pw, Gfx.w(l));
            pw += 14;
            int ph = 16 + RenderMods.ChunkFinder.LINES.size() * 11;
            int py = Math.max(60, mc.getWindow().getScaledHeight() / 2 - ph / 2);
            Gfx.rrect(c, 6, py, pw, ph, 5, Gfx.col(Gfx.BG, 0.85f));
            Gfx.rrect(c, 6, py + 2, 2, ph - 4, 1, Gfx.col(Gfx.GREEN, 1f));
            Gfx.text(c, "Chunk finder", 13, py + 4, Gfx.GREEN, 1f);
            int ly = py + 16;
            for (String l : RenderMods.ChunkFinder.LINES) { Gfx.text(c, l, 13, ly, Gfx.TEXT, 1f); ly += 11; }
        }

        if (!guiOpen) Notifications.render(c);
    }

    /** @return bottom y of the watermark */
    private static int watermark(DrawContext c, MinecraftClient mc, ClientMods.HudModule h) {
        String fpsT = h.fps.value ? mc.getCurrentFps() + " fps" : "";
        int nameW = Gfx.w("DonutMM");
        int w = 10 + 16 + nameW + (fpsT.isEmpty() ? 6 : 12 + Gfx.w(fpsT) + 8) ;
        Gfx.rrect(c, 6, 6, w, 20, 6, Gfx.col(Gfx.accent(), 0.35f));
        Gfx.rrect(c, 7, 7, w - 2, 18, 5, Gfx.col(Gfx.BG, 0.88f));
        Gfx.donut(c, 12, 9, 12, Gfx.BG, 1f);
        int x = 28;
        String name = "DonutMM";
        for (int i = 0; i < name.length(); i++) {
            String ch = String.valueOf(name.charAt(i));
            Gfx.text(c, ch, x, 12, h.wmColor.rgb(i * 0.12f), 1f);
            x += Gfx.w(ch);
        }
        if (!fpsT.isEmpty()) Gfx.text(c, fpsT, x + 10, 12, Gfx.DIM, 1f);
        return 26;
    }

    private static void moduleList(DrawContext c, MinecraftClient mc, ClientMods.HudModule h) {
        int sw = mc.getWindow().getScaledWidth();
        boolean right = h.side.is("Right");
        List<Module> shown = new ArrayList<>();
        for (Module m : Modules.ALL) {
            if (m.exempt || m.permanent || m.hiddenInList) continue;
            float a = m.hudOn.update(m.isEnabled() ? 1 : 0, h.animate.value ? 12 : 60);
            if (a > 0.01f) shown.add(m);
        }
        if (h.sort.is("Alphabetical")) shown.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        else shown.sort((a, b) -> Integer.compare(Gfx.w(b.name), Gfx.w(a.name)));
        int y = 6, n = shown.size(), gap = (int) h.spacing.value;
        for (int i = 0; i < n; i++) {
            Module m = shown.get(i);
            float a = Gfx.ease(m.hudOn.v);
            int bw = Gfx.w(m.name) + 12;
            int slide = Math.round((1f - a) * (bw + 10));
            int x = right ? sw - bw - 6 + slide : 6 - slide;
            int accent = h.colorMode.is("Gradient")
                    ? Gfx.mix(Gfx.accent2(), Gfx.TAN, n <= 1 ? 0 : i / (float) (n - 1))
                    : h.listColor.rgb(i * 0.5f / Math.max(1, n));
            if (h.background.value) Gfx.rrect(c, x, y, bw, 14, 4, Gfx.col(Gfx.BG, h.bgAlpha.f() * a));
            if (h.bar.value) {
                if (right) Gfx.rrect(c, x + bw - 3, y + 2, 2, 10, 1, Gfx.col(accent, a));
                else Gfx.rrect(c, x + 1, y + 2, 2, 10, 1, Gfx.col(accent, a));
            }
            Gfx.text(c, m.name, x + (right ? 6 : 7), y + 3, accent, a);
            y += Math.round((14 + gap) * a);
        }
    }

    private static void infoLines(DrawContext c, MinecraftClient mc, ClientMods.HudModule h, int y) {
        List<String> lines = new ArrayList<>();
        var p = mc.player;
        if (h.coords.value) lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ()));
        if (h.speed.value) {
            double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
            lines.add(String.format(Locale.ROOT, "Speed  %.2f b/s", Math.sqrt(dx * dx + dz * dz) * 20));
        }
        if (h.ping.value && mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            lines.add("Ping  " + (e == null ? "-" : e.getLatency() + " ms"));
        }
        if (h.direction.value) lines.add("Facing  " + p.getHorizontalFacing().asString());
        if (h.lockStatus.value) lines.add("Lock  " + (ServerLock.allowed(mc) ? "allowed" : "blocked"));
        int i = 0;
        for (String s : lines) {
            Gfx.text(c, s, 8, y + i * 11, h.infoColor.rgb(i * 0.3f), 1f);
            i++;
        }
    }
}
