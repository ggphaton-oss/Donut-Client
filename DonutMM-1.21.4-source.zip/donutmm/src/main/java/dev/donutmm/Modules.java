package dev.donutmm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Module registry, shared helpers and settings persistence (config/donutmm-modules.json). */
public final class Modules {
    private Modules() {}

    public static final List<Module> ALL = new ArrayList<>();
    public static ClientMods.Theme theme;
    public static ClientMods.HudModule hud;
    private static CombatMods.HitBox hitBox;

    static {
        MoveMods.register(ALL);
        CombatMods.register(ALL);
        WorldMods.register(ALL);
        RenderMods.register(ALL);
        ClientMods.register(ALL);
        for (Module m : ALL) {
            if (m instanceof ClientMods.Theme t) theme = t;
            if (m instanceof ClientMods.HudModule h) hud = h;
            if (m instanceof CombatMods.HitBox hb) hitBox = hb;
        }
        if (hud != null) hud.loadEnabled(true); // HUD on by default (config can turn it off)
    }

    public static List<Module> in(Module.Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static boolean anyEnabled() {
        for (Module m : ALL) if (m.isEnabled() && !m.exempt) return true;
        return false;
    }

    public static void disableAll() { for (Module m : ALL) m.forceOff(); }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        for (Module m : ALL) if (m.isEnabled()) m.onTick(mc, p);
    }

    /** Keybinds are polled from GLFW (no keybinding registration needed). */
    public static void pollBinds(MinecraftClient mc) {
        long win = mc.getWindow().getHandle();
        for (Module m : ALL) {
            if (m.bind < 0) { m.prevBind = false; continue; }
            boolean down = mc.currentScreen == null && GLFW.glfwGetKey(win, m.bind) == GLFW.GLFW_PRESS;
            if (down && !m.prevBind) m.toggle();
            m.prevBind = down;
        }
    }

    public static void render3D(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        boolean any = false;
        for (Module m : ALL) if (m.isEnabled()) { any = true; break; }
        if (!any || !Render3D.begin(ctx)) return;
        for (Module m : ALL) if (m.isEnabled()) m.onRender3D(mc, p);
        Render3D.end();
    }

    /** Used by EntityMixin. */
    public static float hitboxExpand(Entity e) {
        CombatMods.HitBox h = hitBox;
        return h != null && h.isEnabled() ? h.extra(e) : 0f;
    }

    // ---------------------------------------------------------------- shared helpers

    /** Normalised world-space movement direction from WASD, or null when no key is held. */
    static double[] moveDir(MinecraftClient mc, ClientPlayerEntity p) {
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return null;
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        return new double[]{-sin * f + cos * s, cos * f + sin * s};
    }

    static void setAttr(ClientPlayerEntity p, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attr, double v) {
        EntityAttributeInstance a = p.getAttributeInstance(attr);
        if (a != null && a.getBaseValue() != v) a.setBaseValue(v);
    }

    static float[] rotsTo(ClientPlayerEntity p, Vec3d t) {
        Vec3d eye = p.getEyePos();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[]{(float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float) -Math.toDegrees(Math.atan2(dy, h))};
    }

    static boolean isPlayer(Entity e, ClientPlayerEntity self) { return e instanceof PlayerEntity && e != self; }

    // ---------------------------------------------------------------- persistence

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path cfgPath() { return FabricLoader.getInstance().getConfigDir().resolve("donutmm-modules.json"); }

    public static void loadConfig() {
        try {
            Path p = cfgPath();
            if (!Files.exists(p)) return;
            Map<String, Map<String, Object>> all = GSON.fromJson(Files.readString(p), new TypeToken<Map<String, Map<String, Object>>>() {}.getType());
            if (all == null) return;
            for (Module m : ALL) m.load(all.get(m.name));
        } catch (Exception e) {
            System.err.println("[DonutMM] could not read donutmm-modules.json: " + e);
        }
    }

    public static void saveConfig() {
        try {
            Map<String, Map<String, Object>> all = new LinkedHashMap<>();
            for (Module m : ALL) all.put(m.name, m.save());
            Files.writeString(cfgPath(), GSON.toJson(all));
        } catch (Exception e) {
            System.err.println("[DonutMM] could not save donutmm-modules.json: " + e);
        }
    }
}
