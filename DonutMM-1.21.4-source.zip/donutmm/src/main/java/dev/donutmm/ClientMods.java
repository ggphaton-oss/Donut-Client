package dev.donutmm;

import java.util.List;

/** Cosmetic client modules (not affected by the server lock). */
final class ClientMods {
    private ClientMods() {}

    static void register(List<Module> l) { l.add(new HudModule()); l.add(new Theme()); }

    /** GUI look: accent colour (can be rainbow), dim, animation speed, notifications. */
    static final class Theme extends Module {
        final ColorSet color = color("Accent", 218, 0.82, false);
        final Num dim = num("Background dim", 0.0, 0.9, 0.05, 0.5);
        final Num animSpeed = num("Animation speed", 0.5, 3.0, 0.1, 1.0);
        final Bool notifications = bool("Notifications", true);
        final Bool accentBorder = bool("Glowing window border", true);

        Theme() {
            super("Theme", "GUI accent colour, rainbow, dim", Category.CLIENT);
            exempt = true;
            permanent = true;
        }
    }

    /** On-screen display: watermark, module list, info lines. */
    static final class HudModule extends Module {
        final Label l1 = label("Watermark");
        final Bool watermark = bool("Watermark", true);
        final Bool fps = bool("Show FPS in watermark", true).when(() -> watermark.value);
        final ColorSet wmColor = color("Watermark text", 218, 0.5, false).when(() -> watermark.value);

        final Label l2 = label("Module list");
        final Bool list = bool("Module list", true);
        final Mode side = mode("Side", "Right", "Right", "Left").when(() -> list.value);
        final Mode sort = mode("Sort", "Length", "Length", "Alphabetical").when(() -> list.value);
        final Mode colorMode = mode("Color mode", "Gradient", "Gradient", "Custom").when(() -> list.value);
        final ColorSet listColor = color("List color", 200, 0.7, true).when(() -> list.value && colorMode.is("Custom"));
        final Bool background = bool("Background", true).when(() -> list.value);
        final Num bgAlpha = num("Background opacity", 0.0, 1.0, 0.05, 0.8).when(() -> list.value && background.value);
        final Bool bar = bool("Side bar", true).when(() -> list.value);
        final Num spacing = num("Row spacing", 0, 6, 1, 2).when(() -> list.value);
        final Bool animate = bool("Slide animation", true).when(() -> list.value);

        final Label l3 = label("Info");
        final Bool coords = bool("Coordinates", false);
        final Bool speed = bool("Speed (blocks/s)", false);
        final Bool ping = bool("Ping", false);
        final Bool direction = bool("Facing direction", false);
        final Bool lockStatus = bool("Server lock status", true);
        final ColorSet infoColor = color("Info text", 0, 0.0, false);

        HudModule() {
            super("HUD", "Watermark, module list and info lines", Category.CLIENT);
            exempt = true;
        }
    }
}
