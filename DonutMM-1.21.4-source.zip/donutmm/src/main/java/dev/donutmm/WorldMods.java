package dev.donutmm;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** World interaction + misc test modules. */
final class WorldMods {
    private WorldMods() {}

    static void register(List<Module> l) {
        l.add(new Nuker()); l.add(new Scaffold());
        l.add(new BadPackets()); l.add(new AutoRespawn()); l.add(new AntiAFK());
    }

    // ------------------------------------------------------------------ World

    static final class Nuker extends Module {
        final Mode mode = mode("Mode", "Packet", "Packet", "Legit");
        final Mode filter = mode("Blocks", "All", "All", "Ores only");
        final Num range = num("Range", 1.0, 8.0, 0.1, 4.5);
        final Num perTick = num("Blocks per tick", 1, 40, 1, 4).when(() -> mode.is("Packet"));
        final Num delay = num("Delay (ticks)", 0, 20, 1, 0);
        final Bool swing = bool("Swing hand", true);
        final Bool floorOnly = bool("Skip blocks under feet", true);
        private int cd;

        Nuker() { super("Nuker", "Breaks blocks around you", Category.WORLD); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || mc.interactionManager == null || mc.currentScreen != null || p.networkHandler == null) return;
            if (cd-- > 0) return;
            cd = (int) delay.value;
            int r = (int) Math.ceil(range.value);
            BlockPos base = p.getBlockPos();
            Vec3d eye = p.getEyePos();
            List<BlockPos> hits = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                BlockPos bp = base.add(dx, dy, dz);
                if (floorOnly.value && bp.getY() < p.getBlockY() && bp.getX() == base.getX() && bp.getZ() == base.getZ()) continue;
                if (Vec3d.ofCenter(bp).squaredDistanceTo(eye) > range.value * range.value) continue;
                BlockState st = mc.world.getBlockState(bp);
                if (st.isAir() || !st.getFluidState().isEmpty() || st.getHardness(mc.world, bp) < 0) continue;
                if (filter.is("Ores only")) {
                    String path = Registries.BLOCK.getId(st.getBlock()).getPath();
                    if (!path.endsWith("_ore") && !path.equals("ancient_debris")) continue;
                }
                hits.add(bp);
            }
            if (hits.isEmpty()) return;
            hits.sort((a, b) -> Double.compare(Vec3d.ofCenter(a).squaredDistanceTo(eye), Vec3d.ofCenter(b).squaredDistanceTo(eye)));
            if (mode.is("Legit")) {
                mc.interactionManager.updateBlockBreakingProgress(hits.get(0), Direction.UP);
            } else {
                int n = Math.min(hits.size(), (int) perTick.value);
                for (int i = 0; i < n; i++) {
                    BlockPos bp = hits.get(i);
                    p.networkHandler.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, bp, Direction.UP));
                    p.networkHandler.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, bp, Direction.UP));
                }
            }
            if (swing.value) p.swingHand(Hand.MAIN_HAND);
        }
    }

    static final class Scaffold extends Module {
        final Num delay = num("Delay (ticks)", 0, 10, 1, 0);
        final Num ahead = num("Place ahead (blocks)", 0.0, 3.0, 0.1, 0.0);
        final Bool tower = bool("Tower (hold jump)", false);
        final Num towerSpeed = num("Tower speed", 0.1, 0.6, 0.02, 0.42).when(() -> tower.value);
        final Bool sameY = bool("Keep same Y", false);
        final Bool swing = bool("Swing hand", true);
        private int cd;
        private int lockY = Integer.MIN_VALUE;

        Scaffold() { super("Scaffold", "Places blocks under you (hold a block)", Category.WORLD); }

        @Override public void onEnable() { lockY = Integer.MIN_VALUE; }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (!(p.getMainHandStack().getItem() instanceof BlockItem)) return;
            if (p.isOnGround() || lockY == Integer.MIN_VALUE) lockY = p.getBlockY() - 1;
            if (cd-- > 0) return;
            cd = (int) delay.value;

            double[] d = Modules.moveDir(mc, p);
            double ox = d == null ? 0 : d[0] * ahead.value, oz = d == null ? 0 : d[1] * ahead.value;
            int y = sameY.value ? lockY : p.getBlockY() - 1;
            BlockPos target = BlockPos.ofFloored(p.getX() + ox, y, p.getZ() + oz);
            World w = mc.world;
            if (!w.getBlockState(target).isReplaceable()) {
                if (tower.value && mc.options.jumpKey.isPressed()) {
                    Vec3d v = p.getVelocity();
                    p.setVelocity(v.x, towerSpeed.value, v.z);
                }
                return;
            }
            for (Direction dir : Direction.values()) {
                BlockPos nb = target.offset(dir);
                BlockState st = w.getBlockState(nb);
                if (st.isAir() || !st.getFluidState().isEmpty()) continue;
                Direction face = dir.getOpposite();
                Vec3d hit = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, nb, false));
                if (swing.value) p.swingHand(Hand.MAIN_HAND);
                if (tower.value && mc.options.jumpKey.isPressed()) {
                    Vec3d v = p.getVelocity();
                    p.setVelocity(v.x, towerSpeed.value, v.z);
                }
                return;
            }
        }
    }

    // ------------------------------------------------------------------ Misc

    /** Sends malformed / abusive packets to exercise packet validation in your anticheat. */
    static final class BadPackets extends Module {
        final Mode mode = mode("Mode", "Pitch overflow", "Pitch overflow", "Ground spoof", "Packet spam", "Yaw spin");
        final Num interval = num("Interval (ticks)", 1, 40, 1, 5);
        final Num pitch = num("Pitch value", 91, 180, 1, 120).when(() -> mode.is("Pitch overflow"));
        final Num spamCount = num("Packets per tick", 1, 100, 1, 25).when(() -> mode.is("Packet spam"));
        final Num spinSpeed = num("Spin (deg/packet)", 1, 360, 1, 90).when(() -> mode.is("Yaw spin"));
        private int tick;
        private float yaw;

        BadPackets() { super("BadPackets", "Sends invalid packets (pitch, ground, spam)", Category.MISC); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.networkHandler == null || ++tick % (int) interval.value != 0) return;
            switch (mode.get()) {
                case "Pitch overflow" -> p.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(
                        p.getX(), p.getY(), p.getZ(), p.getYaw(), pitch.f(), p.isOnGround(), p.horizontalCollision));
                case "Ground spoof" -> { if (!p.isOnGround()) p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision)); }
                case "Packet spam" -> {
                    for (int i = 0; i < (int) spamCount.value; i++)
                        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(p.getX(), p.getY(), p.getZ(), p.getYaw() + (i % 2) * 0.1f, p.getPitch(), p.isOnGround(), p.horizontalCollision));
                }
                case "Yaw spin" -> {
                    yaw = MathHelper.wrapDegrees(yaw + spinSpeed.f());
                    p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, p.getPitch(), p.isOnGround(), p.horizontalCollision));
                }
            }
        }
    }

    static final class AutoRespawn extends Module {
        final Num delay = num("Delay (ticks)", 0, 60, 1, 5);
        private int t;

        AutoRespawn() { super("AutoRespawn", "Respawns instantly", Category.MISC); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.currentScreen instanceof DeathScreen) { if (t++ >= delay.value) { p.requestRespawn(); t = 0; } }
            else t = 0;
        }
    }

    static final class AntiAFK extends Module {
        final Num interval = num("Interval (ticks)", 20, 1200, 20, 200);
        final Bool jump = bool("Jump", true);
        final Bool swing = bool("Swing", true);
        final Bool look = bool("Look around", true);
        final Num lookAmount = num("Look amount (deg)", 1, 90, 1, 20).when(() -> look.value);
        private int t;

        AntiAFK() { super("AntiAFK", "Small random actions so you don't idle-kick", Category.MISC); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (++t < interval.value) return;
            t = 0;
            ThreadLocalRandom r = ThreadLocalRandom.current();
            if (jump.value && p.isOnGround()) p.jump();
            if (swing.value) p.swingHand(Hand.MAIN_HAND);
            if (look.value) {
                p.setYaw(p.getYaw() + (float) ((r.nextDouble() * 2 - 1) * lookAmount.value));
                p.setPitch(MathHelper.clamp(p.getPitch() + (float) ((r.nextDouble() * 2 - 1) * lookAmount.value * 0.3), -90f, 90f));
            }
        }
    }
}
