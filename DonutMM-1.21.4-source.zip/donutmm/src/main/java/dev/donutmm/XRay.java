package dev.donutmm;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** State + block filter used by the X-Ray mixin. Chunk meshing runs on worker threads, so keep this thread-safe. */
public final class XRay {
    private XRay() {}

    public static final int ORE = 1, CONTAINER = 2, DEBRIS = 4, SPAWNER = 8, VALUABLE = 16, DIAMOND = 32;

    public static volatile boolean active;
    /** Which block groups stay visible (bit mask of the constants above). */
    public static volatile int mask = ORE | CONTAINER | DEBRIS | SPAWNER;

    private static final Map<Block, Integer> KIND = new ConcurrentHashMap<>();

    private static int kind(Block b) {
        String p = Registries.BLOCK.getId(b).getPath();
        int k = 0;
        if (p.endsWith("_ore")) k |= ORE;
        if (p.equals("ancient_debris")) k |= DEBRIS | VALUABLE;
        if (p.endsWith("diamond_ore")) k |= DIAMOND | VALUABLE;
        if (p.endsWith("emerald_ore")) k |= VALUABLE;
        if (p.equals("spawner") || p.equals("trial_spawner")) k |= SPAWNER;
        if (p.endsWith("chest") || p.equals("barrel") || p.endsWith("shulker_box")) k |= CONTAINER;
        return k;
    }

    public static boolean visible(BlockState state) {
        return (KIND.computeIfAbsent(state.getBlock(), XRay::kind) & mask) != 0;
    }
}
