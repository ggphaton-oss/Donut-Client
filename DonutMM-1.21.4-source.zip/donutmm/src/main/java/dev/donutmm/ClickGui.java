package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Animated click GUI. Mouse buttons are polled from GLFW so this works without
 * touching the (frequently changing) Screen mouse method signatures.
 *   Left click = toggle / change      Right click = expand settings (or previous option)
 *   Middle click on a module = set keybind (then press a key, Esc/Backspace clears)
 * The last tab, "Server Lock", edits the allowed-servers list live (saved to config/donutmm.json).
 */
public final class ClickGui extends Screen {
    private static final int W = 480, H = 300, SIDE = 104, ROW = 30;
    private static final Module.Category[] CATS = Module.Category.values();
    private static final int LOCK = CATS.length; // tab index of the server lock page

    private final Gfx.Anim open = new Gfx.Anim(0), selY = new Gfx.Anim(0), scrollA = new Gfx.Anim(0);
    private final Gfx.Anim[] tabHover = new Gfx.Anim[CATS.length + 1];
    private int tab = 0;
    private boolean closing, prevL, prevR, prevM;
    private float scrollTarget;
    private Module.Num dragging;
    private Module listening;

    // per-frame input snapshot
    private int mx, my;
    private boolean lc, rc, mcl, ld;

    // server lock tab
    private final StringBuilder input = new StringBuilder();
    private boolean focus = true;
    private String msg = "";
    private int msgColor = Gfx.DIM;
    private int lockTotal;

    public ClickGui() {
        super(Text.literal("DonutMM"));
        for (int i = 0; i < tabHover.length; i++) tabHover[i] = new Gfx.Anim(0);
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void close() {
        if (closing) super.close(); else closing = true; // first ESC plays the close animation
    }

    @Override public void removed() { Modules.saveConfig(); }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollTarget -= (float) vertical * 22f;
        return true;
    }

    // ------------------------------------------------------------------ keyboard

    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (listening != null) {
            listening.bind = (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
            Notifications.push(listening.name, listening.bind < 0 ? "Bind cleared" : "Bound to " + keyName(listening.bind), Gfx.accent());
            listening = null;
            return true;
        }
        if (tab == LOCK && focus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (input.length() > 0) input.setLength(input.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { addTyped(); return true; }
            if (key == GLFW.GLFW_KEY_V && (mods & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null) for (char ch : clip.toCharArray()) if (okChar(ch) && input.length() < 80) input.append(ch);
                return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override public boolean charTyped(char chr, int mods) {
        if (tab == LOCK && focus && listening == null) {
            if (okChar(chr) && input.length() < 80) input.append(chr);
            return true;
        }
        return super.charTyped(chr, mods);
    }

    private static boolean okChar(char c) { return Character.isLetterOrDigit(c) || ".-:_[]".indexOf(c) >= 0; }

    private static String keyName(int key) {
        try { return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase(); }
        catch (Exception e) { return "K" + key; }
    }

    private void say(String s, int color) { msg = s; msgColor = color; }

    private void addTyped() {
        String err = ServerLock.addHost(input.toString());
        if (err == null) { say("Added " + ServerLock.hostOf(input.toString()), Gfx.GREEN); input.setLength(0); }
        else say(err, Gfx.RED);
    }

    // ------------------------------------------------------------------ helpers

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int settingsH(Module m) {
        int h = 0;
        for (Module.Setting s : m.visibleSettings()) h += s.height();
        return h;
    }

    /** Small clickable button. Returns true when clicked this frame. */
    private boolean button(DrawContext c, int x, int y, int w, int h, String label, int color, float a, boolean enabled) {
        boolean hov = enabled && in(mx, my, x, y, w, h);
        Gfx.rrect(c, x, y, w, h, 4, Gfx.col(Gfx.mix(Gfx.CARD, color, hov ? 0.45f : 0.22f), a));
        int tw = Gfx.w(label);
        Gfx.text(c, label, x + (w - tw) / 2, y + (h - 8) / 2, Gfx.TEXT, a);
        return hov && lc;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientMods.Theme th = Modules.theme;
        float animSpeed = th == null ? 1f : th.animSpeed.f();
        float o = open.update(closing ? 0 : 1, (closing ? 14 : 9) * animSpeed);
        if (closing && o < 0.03f) { super.close(); return; }
        float e = o;

        // --- input (polled) ---
        long win = mc.getWindow().getHandle();
        ld = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rd = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean md = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        lc = ld && !prevL; rc = rd && !prevR; mcl = md && !prevM;
        prevL = ld; prevR = rd; prevM = md;
        mx = mouseX; my = mouseY;
        if (!ld) dragging = null;
        if (closing) { lc = false; rc = false; mcl = false; dragging = null; }

        // --- window ---
        float dim = th == null ? 0.5f : th.dim.f();
        c.fill(0, 0, width, height, Gfx.col(0x000000, dim * e));
        int ox = (width - W) / 2, oy = (height - H) / 2 + Math.round((1f - e) * 22f);
        boolean glow = th == null || th.accentBorder.value;
        Gfx.rrect(c, ox - 1, oy - 1, W + 2, H + 2, 9, Gfx.col(Gfx.accent(), (glow ? 0.40f : 0.12f) * e));
        Gfx.rrect(c, ox, oy, W, H, 8, Gfx.col(Gfx.BG, e));
        Gfx.rrect(c, ox + 6, oy + 6, SIDE, H - 12, 6, Gfx.col(Gfx.PANEL, e));

        // --- logo ---
        Gfx.donut(c, ox + 14, oy + 14, 16, Gfx.PANEL, e);
        Gfx.boldText(c, "Donut", ox + 35, oy + 18, Gfx.accent2(), e);
        Gfx.boldText(c, "MM", ox + 35 + Gfx.w("Donut") + 1, oy + 18, Gfx.TAN, e);

        // --- tabs ---
        int bx = ox + 10, bw = SIDE - 8;
        float sy = selY.update(tab * 24f, 16);
        Gfx.rrect(c, bx, oy + 42 + Math.round(sy), bw, 21, 5, Gfx.col(Gfx.accent(), 0.20f * e));
        Gfx.rrect(c, bx, oy + 45 + Math.round(sy), 3, 15, 1, Gfx.col(Gfx.accent(), e));
        for (int i = 0; i <= CATS.length; i++) {
            int by = oy + 42 + i * 24;
            boolean hov = !closing && in(mx, my, bx, by, bw, 21);
            float hv = tabHover[i].update(hov ? 1 : 0, 14);
            if (hv > 0.02f && i != tab) Gfx.rrect(c, bx, by, bw, 21, 5, Gfx.col(Gfx.CARD, hv * e));
            boolean on = i == tab;
            int dot = i == LOCK ? Gfx.RED : CATS[i].color;
            String label = i == LOCK ? "Server Lock" : CATS[i].label;
            Gfx.rrect(c, bx + 10, by + 8, 6, 6, 3, Gfx.col(dot, e));
            Gfx.text(c, label, bx + 22, by + 7, on ? Gfx.TEXT : Gfx.mix(Gfx.DIM, Gfx.TEXT, hv), e);
            if (lc && hov && i != tab) { tab = i; scrollTarget = 0; scrollA.v = 0; listening = null; focus = true; }
        }

        // --- server lock status ---
        boolean ok = ServerLock.allowed(mc);
        Gfx.text(c, "Modules", ox + 14, oy + H - 34, Gfx.DIM, e);
        Gfx.rrect(c, ox + 14, oy + H - 22, 6, 6, 3, Gfx.col(ok ? Gfx.GREEN : Gfx.RED, e));
        Gfx.text(c, ok ? "Allowed" : "Blocked", ox + 24, oy + H - 23, ok ? Gfx.GREEN : Gfx.RED, e);

        // --- content area ---
        int cx = ox + SIDE + 14, cy = oy + 36, cw = W - SIDE - 22, ch = H - 44;
        String title = tab == LOCK ? "Server Lock" : CATS[tab].label;
        Gfx.boldText(c, title, cx, oy + 15, Gfx.TEXT, e);
        String hint = tab == LOCK ? "Type a server, press Enter" : "LMB toggle  RMB settings  MMB bind";
        Gfx.text(c, hint, cx + cw - Gfx.w(hint), oy + 15, Gfx.DIM, e * 0.8f);

        if (tab == LOCK) renderLock(c, mc, cx, cy, cw, ch, e);
        else renderModules(c, cx, cy, cw, ch, e);

        Notifications.render(c);
    }

    // ------------------------------------------------------------------ module tabs

    private void renderModules(DrawContext c, int cx, int cy, int cw, int ch, float e) {
        List<Module> mods = Modules.in(CATS[tab]);
        int total = 0;
        for (Module m : mods) {
            int sh = settingsH(m);
            total += ROW - 4 + Math.round(m.expand.v * (sh > 0 ? sh + 4 : 0)) + 4;
        }
        float maxScroll = Math.max(0, total - ch);
        scrollTarget = Gfx.clamp(scrollTarget, 0, maxScroll);
        int scroll = Math.round(scrollA.update(scrollTarget, 14));

        boolean inList = !closing && in(mx, my, cx, cy, cw, ch);
        c.enableScissor(cx, cy, cx + cw, cy + ch);
        int y = cy - scroll;
        for (Module m : mods) {
            int sh = settingsH(m);
            float ex = m.expand.update(m.expanded ? 1 : 0, 12);
            int card = ROW - 4 + Math.round(ex * (sh > 0 ? sh + 4 : 0));
            boolean hdr = inList && in(mx, my, cx, y, cw, ROW - 4);
            float hv = m.hover.update(hdr ? 1 : 0, 14);
            float on = m.guiOn.update(m.isEnabled() && !m.permanent ? 1 : 0, 14);

            Gfx.rrect(c, cx, y, cw, card, 5, Gfx.col(Gfx.mix(Gfx.CARD, Gfx.CARD_H, hv), e));
            if (on > 0.02f) Gfx.rrect(c, cx, y + 5, 3, ROW - 14, 1, Gfx.col(Gfx.accent(), on * e));
            Gfx.text(c, m.name, cx + 12, y + 5, Gfx.mix(Gfx.TEXT, Gfx.accent2(), on), e);
            Gfx.text(c, m.description, cx + 12, y + 15, Gfx.DIM, e);
            int right = cx + cw - 10;
            if (!m.permanent) {
                Gfx.toggle(c, cx + cw - 36, y + (ROW - 4 - 12) / 2, on, e);
                right = cx + cw - 46;
            }
            if (sh > 0) {
                int dc = Gfx.col(Gfx.mix(Gfx.DIM, Gfx.accent2(), ex), e);
                for (int k = 0; k < 3; k++) c.fill(right, y + 9 + k * 4, right + 2, y + 11 + k * 4, dc);
                right -= 10;
            }
            if (listening == m || m.bind >= 0) {
                String b = listening == m ? "press key..." : "[" + keyName(m.bind) + "]";
                Gfx.text(c, b, right - Gfx.w(b), y + 10, listening == m ? Gfx.TAN : Gfx.DIM, e);
            }
            if (hdr) {
                if (lc) { if (m.permanent) m.expanded = !m.expanded; else m.toggle(); }
                if (rc && sh > 0) m.expanded = !m.expanded;
                if (mcl && !m.permanent) listening = listening == m ? null : m;
            }

            if (ex > 0.03f && sh > 0) {
                c.enableScissor(cx, Math.max(cy, y + ROW - 4), cx + cw, Math.min(cy + ch, y + card));
                int sy2 = y + ROW - 2;
                float sa = e * ex;
                boolean live = inList && ex > 0.9f;
                for (Module.Setting s : m.visibleSettings()) {
                    int sx = cx + (s.sub ? 10 : 0), sw = cw - (s.sub ? 10 : 0);
                    drawSetting(c, s, sx, sy2, sw, sa, live);
                    sy2 += s.height();
                }
                c.disableScissor();
            }
            y += card + 4;
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int bh = Math.max(16, Math.round(ch * (ch / (float) total)));
            int by = cy + Math.round((ch - bh) * (scroll / maxScroll));
            Gfx.rrect(c, cx + cw + 4, by, 2, bh, 1, Gfx.col(Gfx.accent(), 0.7f * e));
        }
    }

    private void drawSetting(DrawContext c, Module.Setting s, int x, int y, int w, float a, boolean live) {
        if (s instanceof Module.Label l) {
            int tw = Gfx.w(l.shown);
            Gfx.text(c, l.shown, x + 12, y + 4, Gfx.accent2(), a);
            c.fill(x + 18 + tw, y + 8, x + w - 12, y + 9, Gfx.col(Gfx.OFF, a));
        } else if (s instanceof Module.Bool b) {
            boolean row = live && in(mx, my, x, y, w, 20);
            Gfx.text(c, b.shown, x + 12, y + 6, Gfx.TEXT, a);
            Gfx.toggle(c, x + w - 36, y + 4, b.anim.update(b.value ? 1 : 0, 14), a);
            if (lc && row) b.value = !b.value;
        } else if (s instanceof Module.Num n) {
            int tx = x + 12, tw = w - 24;
            boolean row = live && in(mx, my, x + 6, y + 12, w - 12, 16);
            if (lc && row) dragging = n;
            if (dragging == n && ld) {
                double r = Math.max(0, Math.min(1, (mx - tx) / (double) tw));
                double v = n.min + r * (n.max - n.min);
                v = Math.round(v / n.step) * n.step;
                n.value = Math.max(n.min, Math.min(n.max, v));
            }
            float rr = n.anim.update(n.ratio(), 22);
            Gfx.text(c, n.shown, x + 12, y + 3, Gfx.TEXT, a);
            String val = n.display();
            Gfx.text(c, val, x + w - 12 - Gfx.w(val), y + 3, Gfx.accent2(), a);
            Gfx.rrect(c, tx, y + 17, tw, 4, 2, Gfx.col(Gfx.OFF, a));
            int fw = Math.round(tw * rr);
            Gfx.rrect(c, tx, y + 17, Math.max(fw, 4), 4, 2, Gfx.col(Gfx.accent(), a));
            Gfx.rrect(c, tx + fw - 3, y + 15, 7, 8, 3, Gfx.col(0xFFFFFF, a));
        } else if (s instanceof Module.Mode m) {
            boolean row = live && in(mx, my, x, y, w, 20);
            String v = m.get();
            int vw = Gfx.w(v) + 20;
            Gfx.text(c, m.shown, x + 12, y + 6, Gfx.TEXT, a);
            Gfx.rrect(c, x + w - 12 - vw, y + 2, vw, 16, 4, Gfx.col(row ? Gfx.CARD_H : Gfx.PANEL, a));
            Gfx.text(c, "<", x + w - 12 - vw + 4, y + 6, Gfx.DIM, a);
            Gfx.text(c, v, x + w - 12 - vw + 10, y + 6, Gfx.accent2(), a);
            Gfx.text(c, ">", x + w - 16, y + 6, Gfx.DIM, a);
            if (row && lc) m.next(1);
            if (row && rc) m.next(-1);
        } else if (s instanceof Module.ColorSet cs) {
            boolean row = live && in(mx, my, x, y, w, 20);
            Gfx.text(c, cs.shown, x + 12, y + 6, Gfx.TEXT, a);
            int rgb = cs.rgb(0f);
            Gfx.rrect(c, x + w - 12 - 36, y + 3, 36, 14, 4, Gfx.col(0xFFFFFF, a * 0.35f));
            Gfx.rrect(c, x + w - 12 - 35, y + 4, 34, 12, 3, Gfx.col(rgb, a));
            if (cs.rainbow.value) Gfx.text(c, "rainbow", x + w - 12 - 36 - 6 - Gfx.w("rainbow"), y + 6, Gfx.TAN, a * 0.9f);
            else Gfx.text(c, cs.open ? "v" : ">", x + w - 12 - 36 - 12, y + 6, Gfx.DIM, a);
            if (row && lc) cs.open = !cs.open;
        }
    }

    // ------------------------------------------------------------------ server lock tab

    private void renderLock(DrawContext c, MinecraftClient mc, int cx, int cy, int cw, int ch, float e) {
        float maxScroll = Math.max(0, lockTotal - ch);
        scrollTarget = Gfx.clamp(scrollTarget, 0, maxScroll);
        int scroll = Math.round(scrollA.update(scrollTarget, 14));
        boolean inList = !closing && in(mx, my, cx, cy, cw, ch);
        boolean lcl = lc && inList; // clicks only count inside the content area
        boolean saveLc = lc;
        lc = lcl;

        c.enableScissor(cx, cy, cx + cw, cy + ch);
        int y = cy - scroll;
        int top = y;

        // --- status card ---
        String addr = ServerLock.currentAddress(mc);
        boolean inWorld = mc.player != null && mc.world != null;
        String where = !inWorld ? "Not in a world" : mc.isInSingleplayer() ? "Singleplayer" : (addr.isEmpty() ? "Unknown server" : addr);
        boolean ok = ServerLock.allowed(mc);
        Gfx.rrect(c, cx, y, cw, 34, 5, Gfx.col(Gfx.CARD, e));
        Gfx.rrect(c, cx, y + 5, 3, 24, 1, Gfx.col(ok ? Gfx.GREEN : Gfx.RED, e));
        Gfx.text(c, "Current: " + where, cx + 12, y + 7, Gfx.TEXT, e);
        Gfx.text(c, ok ? "Modules are allowed here" : (inWorld ? "Modules are blocked here" : "Join a world to test"), cx + 12, y + 19, ok ? Gfx.GREEN : Gfx.DIM, e);
        y += 40;

        // --- allowed hosts ---
        Gfx.text(c, "Allowed servers", cx + 2, y + 2, Gfx.accent2(), e);
        c.fill(cx + 8 + Gfx.w("Allowed servers"), y + 6, cx + cw - 2, y + 7, Gfx.col(Gfx.OFF, e));
        y += 15;
        List<String> hosts = ServerLock.hosts();
        if (hosts.isEmpty()) { Gfx.text(c, "Nothing allowed, only singleplayer (if enabled)", cx + 12, y + 3, Gfx.DIM, e); y += 18; }
        for (String hst : hosts) {
            Gfx.rrect(c, cx, y, cw, 18, 4, Gfx.col(Gfx.CARD, e));
            Gfx.text(c, hst, cx + 10, y + 5, Gfx.TEXT, e);
            if (button(c, cx + cw - 20, y + 2, 14, 14, "x", Gfx.RED, e, inList)) { ServerLock.removeHost(hst); say("Removed " + hst, Gfx.DIM); }
            y += 21;
        }
        y += 3;

        // --- input row ---
        int boxW = cw - 62;
        boolean overBox = inList && in(mx, my, cx, y, boxW, 20);
        if (lc && overBox) focus = true;
        else if (lc && !in(mx, my, cx, y, cw, 20)) focus = false;
        Gfx.rrect(c, cx - 1, y - 1, boxW + 2, 22, 5, Gfx.col(focus ? Gfx.accent() : Gfx.OFF, 0.7f * e));
        Gfx.rrect(c, cx, y, boxW, 20, 4, Gfx.col(Gfx.PANEL, e));
        String shownText = input.toString();
        if (shownText.isEmpty() && !focus) Gfx.text(c, "server.address.com", cx + 8, y + 6, Gfx.DIM, e * 0.7f);
        else {
            boolean caret = focus && (System.currentTimeMillis() / 500) % 2 == 0;
            String t = shownText;
            while (Gfx.w(t) > boxW - 18 && t.length() > 1) t = t.substring(1);
            Gfx.text(c, t + (caret ? "_" : ""), cx + 8, y + 6, Gfx.TEXT, e);
            if (shownText.isEmpty() && focus && !caret) Gfx.text(c, "server.address.com", cx + 8, y + 6, Gfx.DIM, e * 0.5f);
        }
        if (button(c, cx + boxW + 6, y, 56, 20, "Add", Gfx.GREEN, e, inList)) addTyped();
        y += 26;

        // --- add current server shortcut ---
        if (inWorld && !mc.isInSingleplayer() && !addr.isEmpty()) {
            boolean already = ServerLock.hostAllowed(addr);
            String lbl = already ? "Current server already allowed" : "+ Allow current server (" + ServerLock.hostOf(addr) + ")";
            if (button(c, cx, y, cw, 20, lbl, already ? Gfx.OFF : Gfx.BLUE, e, inList && !already)) {
                String err = ServerLock.addHost(addr);
                say(err == null ? "Added " + ServerLock.hostOf(addr) : err, err == null ? Gfx.GREEN : Gfx.RED);
            }
            y += 25;
        }
        if (!msg.isEmpty()) { Gfx.text(c, msg, cx + 2, y + 1, msgColor, e); y += 14; }
        y += 4;

        // --- options ---
        Gfx.text(c, "Options", cx + 2, y + 2, Gfx.accent2(), e);
        c.fill(cx + 8 + Gfx.w("Options"), y + 6, cx + cw - 2, y + 7, Gfx.col(Gfx.OFF, e));
        y += 15;
        boolean disc = ServerLock.disconnectOnBlocked();
        Gfx.rrect(c, cx, y, cw, 20, 4, Gfx.col(Gfx.CARD, e));
        Gfx.text(c, "Disconnect when server isn't allowed", cx + 10, y + 6, Gfx.TEXT, e);
        Gfx.toggle(c, cx + cw - 36, y + 4, disc ? 1f : 0f, e);
        if (lc && in(mx, my, cx, y, cw, 20)) ServerLock.setDisconnectOnBlocked(!disc);
        y += 24;
        boolean sp = ServerLock.allowSingleplayer();
        Gfx.rrect(c, cx, y, cw, 20, 4, Gfx.col(Gfx.CARD, e));
        Gfx.text(c, "Allow modules in singleplayer", cx + 10, y + 6, Gfx.TEXT, e);
        Gfx.toggle(c, cx + cw - 36, y + 4, sp ? 1f : 0f, e);
        if (lc && in(mx, my, cx, y, cw, 20)) ServerLock.setAllowSingleplayer(!sp);
        y += 28;

        Gfx.text(c, "DonutSMP is hard-blocked in code and can't be added.", cx + 2, y, Gfx.DIM, e * 0.8f);
        y += 12;
        Gfx.text(c, "Subdomains are included (example.com allows play.example.com).", cx + 2, y, Gfx.DIM, e * 0.8f);
        y += 14;

        lockTotal = y - top;
        c.disableScissor();
        lc = saveLc;

        if (maxScroll > 0) {
            int bh = Math.max(16, Math.round(ch * (ch / (float) lockTotal)));
            int by = cy + Math.round((ch - bh) * (scroll / maxScroll));
            Gfx.rrect(c, cx + cw + 4, by, 2, bh, 1, Gfx.col(Gfx.accent(), 0.7f * e));
        }
    }
}
