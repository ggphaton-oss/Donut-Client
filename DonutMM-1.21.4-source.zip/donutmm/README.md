# DonutMM (anticheat test client) for Minecraft 1.21.4

Fabric client for testing your own anticheat. Original code, no third-party client source.

**Safety lock:** modules only run in singleplayer or on servers in your allow list.
Edit the list live in the GUI (**Server Lock** tab), no recompiling. It is saved to `config/donutmm.json`.
DonutSMP is hard-blocked in code and can't be added.

**Open menu:** Right Shift
- Left click: toggle module / change setting  
- Right click: open settings (or previous option on a mode setting)  
- Middle click on a module: set a keybind (Esc / Backspace clears)  
- Click a colour row to open Hue / Saturation / Brightness / **Rainbow** / speed / spread  
- All settings, binds and the HUD are saved to `config/donutmm-modules.json` when you close the menu.

## Modules
**Movement:** Speed (Set, Bhop, Strafe, Multiply, OnGround) · Fly (Velocity, Abilities, Glide, Jetpack) · NoFall · Step (+reverse) · Timer (extra move packets) · Jesus · Phase · Spider · HighJump · AirJump · Sprint · AutoWalk  
**Combat:** KillAura (priority, FOV, rotations, CPS style, multi-target, hit chance) · Reach · HitBox · Criticals · AutoClicker · Triggerbot · AimAssist · AutoTotem  
**World:** Nuker (packet / legit) · Scaffold  
**Render:** ESP (box styles, rainbow, health/distance colours, tracers) · StorageESP · BlockESP · Fullbright · X-Ray · ChunkFinder  
**Misc:** BadPackets (pitch overflow, ground spoof, packet spam, yaw spin) · AutoRespawn · AntiAFK  
**Client:** HUD (watermark, module list, info lines, rainbow) · Theme (GUI accent colour / rainbow)

X-Ray needs vanilla chunk rendering (not Sodium).

## Build with GitHub (works from a phone)
1. Make a new GitHub repository.
2. **Add file > Upload files** and upload `DonutMM-1.21.4-source.zip` (leave it zipped) > Commit.
3. **Add file > Create new file**, name it `.github/workflows/build.yml`, paste in the contents of `build.yml` > Commit.
4. Open the **Actions** tab and wait for the green check.
5. Get the jar from the repo's **Releases** (right side of the repo page), or from the run's **Artifacts**.
6. Put `donutmm-1.1.0.jar` in `mods/` with Fabric Loader 0.16+ and Fabric API for 1.21.4.

The workflow unzips the source zip automatically. If you upload the unzipped files instead, that works too.

## Build on PC
JDK 21 + Gradle 8.12, then `gradle build`. The jar is in `build/libs/`.
