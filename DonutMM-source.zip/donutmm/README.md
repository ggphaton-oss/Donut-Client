# DonutMM (anticheat test client)

Fabric 1.21.11 client for testing your own anticheat. Original code, no third-party client source.

**Safety:** modules only run in singleplayer or on hosts in `config/donutmm.json` (`allowedHosts`).
DonutSMP is hard-blocked in code and can't be added. First launch creates the config with localhost only;
add your test server IP there.

**Open menu:** Right Shift. LMB toggles, RMB expands settings.

**Modules:** Speed, Fly, NoFall, Step (Movement) | KillAura, Reach, AutoClicker (Combat).

## Build on your phone (no PC)
1. github.com > New repository (any name).
2. Add file > Upload files > upload **DonutMM-source.zip** (just the zip, don't unzip it) > Commit.
3. Add file > Create new file > name it `.github/workflows/build.yml` > paste the contents of **build.yml** > Commit.
4. Actions tab > open the "build" run > wait for the green check > download **DonutMM-jar** under Artifacts.
5. Unzip it and put `donutmm-1.0.0.jar` in `mods/` (Fabric Loader 0.18+ and Fabric API for 1.21.11).

## Build on PC
Install JDK 21 + Gradle 9.2, then run `gradle build`. Jar is in `build/libs/`.
