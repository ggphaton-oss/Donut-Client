package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        MOVEMENT("Movement", Gfx.BLUE2), COMBAT("Combat", Gfx.TAN);
        public final String label;
        public final int color;
        Category(String label, int color) { this.label = label; this.color = color; }
    }

    public abstract static class Setting {
        public final String name;
        protected Setting(String name) { this.name = name; }
    }

    public static final class Bool extends Setting {
        public boolean value;
        public final Gfx.Anim anim;
        Bool(String name, boolean value) { super(name); this.value = value; this.anim = new Gfx.Anim(value ? 1 : 0); }
    }

    public static final class Num extends Setting {
        public final double min, max, step;
        public double value;
        public final int decimals;
        public final Gfx.Anim anim;
        Num(String name, double min, double max, double step, double value) {
            super(name);
            this.min = min; this.max = max; this.step = step; this.value = value;
            this.decimals = step >= 1 ? 0 : (step >= 0.1 ? 1 : 2);
            this.anim = new Gfx.Anim((float) ((value - min) / (max - min)));
        }
        public String display() { return String.format("%." + decimals + "f", value); }
        public float ratio() { return (float) ((value - min) / (max - min)); }
    }

    public final String name, description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();

    // GUI / HUD animation state
    public final Gfx.Anim guiOn = new Gfx.Anim(0), hudOn = new Gfx.Anim(0), hover = new Gfx.Anim(0), expand = new Gfx.Anim(0);
    public boolean expanded;

    private boolean enabled;

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Bool bool(String n, boolean d) { Bool b = new Bool(n, d); settings.add(b); return b; }
    protected Num num(String n, double min, double max, double step, double d) { Num x = new Num(n, min, max, step, d); settings.add(x); return x; }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (on && !ServerLock.allowed(mc)) {
            Notifications.push("Locked", "Join singleplayer or an allowed server", Gfx.RED);
            return;
        }
        enabled = on;
        if (on) onEnable(); else onDisable();
        Notifications.push(name, on ? "Enabled" : "Disabled", on ? Gfx.GREEN : Gfx.DIM);
    }

    /** Turn off without popup (used by the lock and on disconnect). */
    public void forceOff() {
        if (!enabled) return;
        enabled = false;
        onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {}
}
