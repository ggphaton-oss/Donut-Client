package dev.donutmm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Safety lock: cheats only run in singleplayer or on hosts listed in config/donutmm.json.
 * DonutSMP is hard-blocked and cannot be added through the config.
 */
public final class ServerLock {
    private ServerLock() {}

    private static final String[] HARD_BLOCK = {"donutsmp"};

    public static final class Config {
        public List<String> allowedHosts = new ArrayList<>(List.of("localhost", "127.0.0.1"));
        public boolean disconnectOnBlocked = true;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config cfg = new Config();

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("donutmm.json");
        try {
            if (Files.exists(p)) {
                Config read = GSON.fromJson(Files.readString(p), Config.class);
                if (read != null && read.allowedHosts != null) cfg = read;
            } else {
                Files.writeString(p, GSON.toJson(cfg));
            }
        } catch (Exception e) {
            System.err.println("[DonutMM] config error, using defaults: " + e);
        }
    }

    public static boolean disconnectOnBlocked() { return cfg.disconnectOnBlocked; }

    public static String hostOf(String address) {
        if (address == null) return "";
        String h = address.trim().toLowerCase(Locale.ROOT);
        if (h.startsWith("[")) { // [::1]:25565
            int end = h.indexOf(']');
            return end > 0 ? h.substring(1, end) : h;
        }
        int colon = h.lastIndexOf(':');
        if (colon > 0 && h.indexOf(':') == colon) h = h.substring(0, colon);
        return h;
    }

    public static boolean hostAllowed(String address) {
        String host = hostOf(address);
        if (host.isEmpty()) return false;
        for (String b : HARD_BLOCK) if (host.contains(b)) return false;
        for (String a : cfg.allowedHosts) {
            String entry = hostOf(a);
            if (entry.isEmpty()) continue;
            if (host.equals(entry) || host.endsWith("." + entry)) return true;
        }
        return false;
    }

    /** True when it is safe to run cheat modules right now. */
    public static boolean allowed(MinecraftClient mc) {
        if (mc == null || mc.player == null || mc.world == null) return false;
        if (mc.isInSingleplayer()) return true;
        ServerInfo info = mc.getCurrentServerEntry();
        return info != null && hostAllowed(info.address);
    }
}
