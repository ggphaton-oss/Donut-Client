package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext c, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        boolean guiOpen = mc.currentScreen instanceof ClickGui;

        // Watermark
        String fps = mc.getCurrentFps() + " fps";
        int w = 10 + 16 + Gfx.w("Donut") + Gfx.w("MM") + 12 + Gfx.w(fps) + 8;
        Gfx.rrect(c, 6, 6, w, 20, 6, Gfx.col(Gfx.BLUE, 0.35f));
        Gfx.rrect(c, 7, 7, w - 2, 18, 5, Gfx.col(Gfx.BG, 0.88f));
        Gfx.donut(c, 12, 9, 12, Gfx.BG, 1f);
        int tx = 28;
        Gfx.text(c, "Donut", tx, 12, Gfx.BLUE2, 1f);
        Gfx.text(c, "MM", tx + Gfx.w("Donut"), 12, Gfx.TAN, 1f);
        Gfx.text(c, fps, tx + Gfx.w("DonutMM") + 10, 12, Gfx.DIM, 1f);

        // Module list (slides in from the right)
        int sw = mc.getWindow().getScaledWidth();
        List<Module> shown = new ArrayList<>();
        for (Module m : Modules.ALL) {
            float a = m.hudOn.update(m.isEnabled() ? 1 : 0, 12);
            if (a > 0.01f) shown.add(m);
        }
        shown.sort((a, b) -> Integer.compare(Gfx.w(b.name), Gfx.w(a.name)));
        int y = 6, n = shown.size();
        for (int i = 0; i < n; i++) {
            Module m = shown.get(i);
            float a = Gfx.ease(m.hudOn.v);
            int bw = Gfx.w(m.name) + 12;
            int x = sw - bw - 6 + Math.round((1f - a) * (bw + 10));
            int accent = Gfx.mix(Gfx.BLUE2, Gfx.TAN, n <= 1 ? 0 : i / (float) (n - 1));
            Gfx.rrect(c, x, y, bw, 14, 4, Gfx.col(Gfx.BG, 0.82f * a));
            Gfx.rrect(c, x + bw - 3, y + 2, 2, 10, 1, Gfx.col(accent, a));
            Gfx.text(c, m.name, x + 6, y + 3, accent, a);
            y += Math.round(16 * a);
        }

        if (!guiOpen) Notifications.render(c);
    }
}
