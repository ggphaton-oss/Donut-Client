package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Test modules for tuning an anticheat. Each setting is adjustable so you can sit
 * just above / below your own thresholds. They only run where ServerLock allows.
 */
public final class Modules {
    private Modules() {}

    public static final List<Module> ALL = new ArrayList<>();

    static {
        ALL.add(new Speed());
        ALL.add(new Fly());
        ALL.add(new NoFall());
        ALL.add(new Step());
        ALL.add(new KillAura());
        ALL.add(new Reach());
        ALL.add(new AutoClicker());
    }

    public static List<Module> in(Module.Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static boolean anyEnabled() {
        for (Module m : ALL) if (m.isEnabled()) return true;
        return false;
    }

    public static void disableAll() { for (Module m : ALL) m.forceOff(); }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        for (Module m : ALL) if (m.isEnabled()) m.onTick(mc, p);
    }

    /** Normalised world-space movement direction from WASD, or null when no key is held. */
    static double[] moveDir(MinecraftClient mc, ClientPlayerEntity p) {
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return null;
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        return new double[]{-sin * f + cos * s, cos * f + sin * s};
    }

    static void setAttr(ClientPlayerEntity p, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attr, double v) {
        EntityAttributeInstance a = p.getAttributeInstance(attr);
        if (a != null && a.getBaseValue() != v) a.setBaseValue(v);
    }

    // ---------------------------------------------------------------- MOVEMENT

    static final class Speed extends Module {
        final Num speed = num("Speed (b/tick)", 0.10, 1.50, 0.05, 0.40);
        final Bool air = bool("Apply in air", true);

        Speed() { super("Speed", "Horizontal speed override", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (!air.value && !p.isOnGround()) return;
            double[] d = moveDir(mc, p);
            if (d == null) return;
            p.setVelocity(d[0] * speed.value, p.getVelocity().y, d[1] * speed.value);
        }
    }

    static final class Fly extends Module {
        final Num horizontal = num("Horizontal", 0.05, 2.00, 0.05, 0.50);
        final Num vertical = num("Vertical", 0.05, 2.00, 0.05, 0.40);

        Fly() { super("Fly", "Free flight (jump up, sneak down)", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            double[] d = moveDir(mc, p);
            double vx = d == null ? 0 : d[0] * horizontal.value;
            double vz = d == null ? 0 : d[1] * horizontal.value;
            double vy = 0;
            if (mc.options.jumpKey.isPressed()) vy = vertical.value;
            else if (mc.options.sneakKey.isPressed()) vy = -vertical.value;
            p.setVelocity(vx, vy, vz);
        }
    }

    static final class NoFall extends Module {
        final Num distance = num("Trigger distance", 1.0, 10.0, 0.5, 2.5);

        NoFall() { super("NoFall", "Spoofs on-ground to skip fall damage", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (p.fallDistance > distance.value && p.networkHandler != null) {
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
            }
        }
    }

    static final class Step extends Module {
        final Num height = num("Height", 0.6, 5.0, 0.1, 1.5);

        Step() { super("Step", "Raises step height", Category.MOVEMENT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) { setAttr(p, EntityAttributes.STEP_HEIGHT, height.value); }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) setAttr(p, EntityAttributes.STEP_HEIGHT, 0.6);
        }
    }

    // ------------------------------------------------------------------ COMBAT

    static final class KillAura extends Module {
        final Num range = num("Range", 2.5, 8.0, 0.1, 4.0);
        final Num cps = num("CPS", 1, 20, 1, 10);
        final Bool playersOnly = bool("Players only", true);
        final Bool rotate = bool("Snap rotation", true);
        final Bool cooldown = bool("Wait for cooldown", false);
        private long last;

        KillAura() { super("KillAura", "Auto-attacks nearest target", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            long now = System.nanoTime();
            if (now - last < (long) (1e9 / cps.value)) return;
            if (cooldown.value && p.getAttackCooldownProgress(0.5f) < 0.95f) return;

            LivingEntity best = null;
            double bestD = range.value;
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity le) || le == p || !le.isAlive() || le.isSpectator() || le instanceof ArmorStandEntity) continue;
                if (playersOnly.value && !(le instanceof PlayerEntity)) continue;
                double d = p.distanceTo(le);
                if (d <= bestD) { bestD = d; best = le; }
            }
            if (best == null) return;

            if (rotate.value) {
                Vec3d eye = p.getEyePos();
                Vec3d t = best.getBoundingBox().getCenter();
                double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
                double h = Math.sqrt(dx * dx + dz * dz);
                p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
                p.setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
            }
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
            last = now;
        }
    }

    static final class Reach extends Module {
        final Num entity = num("Entity reach", 3.0, 8.0, 0.1, 4.5);
        final Bool blocks = bool("Also blocks", false);
        final Num block = num("Block reach", 4.5, 10.0, 0.1, 6.0);

        Reach() { super("Reach", "Extends interaction range", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            setAttr(p, EntityAttributes.ENTITY_INTERACTION_RANGE, entity.value);
            setAttr(p, EntityAttributes.BLOCK_INTERACTION_RANGE, blocks.value ? block.value : 4.5);
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p == null) return;
            setAttr(p, EntityAttributes.ENTITY_INTERACTION_RANGE, 3.0);
            setAttr(p, EntityAttributes.BLOCK_INTERACTION_RANGE, 4.5);
        }
    }

    static final class AutoClicker extends Module {
        final Num cps = num("CPS (max 20)", 1, 20, 1, 12);
        final Bool randomize = bool("Randomize timing", false);
        private long next;

        AutoClicker() { super("AutoClicker", "Clicks while attack is held on an entity", Category.COMBAT); }

        @Override public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
            if (mc.currentScreen != null || mc.interactionManager == null || !mc.options.attackKey.isPressed()) return;
            if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
            long now = System.nanoTime();
            if (now < next) return;
            mc.interactionManager.attackEntity(p, hit.getEntity());
            p.swingHand(Hand.MAIN_HAND);
            double gap = 1e9 / cps.value;
            if (randomize.value) gap *= 0.75 + ThreadLocalRandom.current().nextDouble() * 0.5;
            next = now + (long) gap;
        }
    }
}
