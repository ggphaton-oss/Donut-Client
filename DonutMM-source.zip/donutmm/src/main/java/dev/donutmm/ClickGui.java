package dev.donutmm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Animated click GUI. Mouse buttons are polled from GLFW so this works without
 * touching the (frequently changing) Screen input method signatures.
 *   Left click  = toggle module / setting      Right click = expand settings
 */
public final class ClickGui extends Screen {
    private static final int W = 396, H = 256, SIDE = 98, ROW = 30;

    private final Gfx.Anim open = new Gfx.Anim(0), selY = new Gfx.Anim(0), scrollA = new Gfx.Anim(0);
    private final Gfx.Anim[] catHover;
    private Module.Category sel = Module.Category.MOVEMENT;
    private boolean closing, prevL, prevR;
    private float scrollTarget;
    private Module.Num dragging;

    public ClickGui() {
        super(Text.literal("DonutMM"));
        catHover = new Gfx.Anim[Module.Category.values().length];
        for (int i = 0; i < catHover.length; i++) catHover[i] = new Gfx.Anim(0);
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void close() {
        if (closing) super.close(); else closing = true; // first ESC plays the close animation
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollTarget -= (float) vertical * 22f;
        return true;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int settingH(Module.Setting s) { return s instanceof Module.Num ? 28 : 20; }

    private static int settingsH(Module m) {
        int h = 0;
        for (Module.Setting s : m.settings) h += settingH(s);
        return h;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float o = open.update(closing ? 0 : 1, closing ? 14 : 9);
        if (closing && o < 0.03f) { super.close(); return; }
        float e = o;

        // --- input (polled) ---
        long win = mc.getWindow().getHandle();
        boolean ld = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rd = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean lc = ld && !prevL, rc = rd && !prevR;
        prevL = ld; prevR = rd;
        if (!ld) dragging = null;
        if (closing) { lc = false; rc = false; dragging = null; }

        // --- window ---
        c.fill(0, 0, width, height, Gfx.col(0x000000, 0.50f * e));
        int ox = (width - W) / 2, oy = (height - H) / 2 + Math.round((1f - e) * 22f);
        Gfx.rrect(c, ox - 1, oy - 1, W + 2, H + 2, 9, Gfx.col(Gfx.BLUE, 0.32f * e));
        Gfx.rrect(c, ox, oy, W, H, 8, Gfx.col(Gfx.BG, e));
        Gfx.rrect(c, ox + 6, oy + 6, SIDE, H - 12, 6, Gfx.col(Gfx.PANEL, e));

        // --- logo ---
        Gfx.donut(c, ox + 14, oy + 14, 16, Gfx.PANEL, e);
        Gfx.boldText(c, "Donut", ox + 35, oy + 18, Gfx.BLUE2, e);
        Gfx.boldText(c, "MM", ox + 35 + Gfx.w("Donut") + 1, oy + 18, Gfx.TAN, e);

        // --- categories ---
        Module.Category[] cats = Module.Category.values();
        int idx = sel.ordinal();
        float sy = selY.update(idx * 26f, 16);
        int bx = ox + 10, bw = SIDE - 8;
        Gfx.rrect(c, bx, oy + 44 + Math.round(sy), bw, 22, 5, Gfx.col(Gfx.BLUE, 0.20f * e));
        Gfx.rrect(c, bx, oy + 48 + Math.round(sy), 3, 14, 1, Gfx.col(Gfx.BLUE, e));
        for (int i = 0; i < cats.length; i++) {
            int by = oy + 44 + i * 26;
            boolean hov = !closing && in(mx, my, bx, by, bw, 22);
            float hv = catHover[i].update(hov ? 1 : 0, 14);
            if (hv > 0.02f && cats[i] != sel) Gfx.rrect(c, bx, by, bw, 22, 5, Gfx.col(Gfx.CARD, hv * e));
            boolean on = cats[i] == sel;
            Gfx.rrect(c, bx + 10, by + 8, 6, 6, 3, Gfx.col(cats[i].color, e));
            Gfx.text(c, cats[i].label, bx + 22, by + 7, on ? Gfx.TEXT : Gfx.mix(Gfx.DIM, Gfx.TEXT, hv), e);
            if (lc && hov && cats[i] != sel) { sel = cats[i]; scrollTarget = 0; scrollA.v = 0; }
        }

        // --- server lock status ---
        boolean ok = ServerLock.allowed(mc);
        Gfx.text(c, "Server lock", ox + 14, oy + H - 34, Gfx.DIM, e);
        Gfx.rrect(c, ox + 14, oy + H - 22, 6, 6, 3, Gfx.col(ok ? Gfx.GREEN : Gfx.RED, e));
        Gfx.text(c, ok ? "Allowed" : "Blocked", ox + 24, oy + H - 23, ok ? Gfx.GREEN : Gfx.RED, e);

        // --- content area ---
        int cx = ox + SIDE + 14, cy = oy + 36, cw = W - SIDE - 22, ch = H - 44;
        Gfx.boldText(c, sel.label, cx, oy + 15, Gfx.TEXT, e);
        String hint = "LMB toggle   RMB settings";
        Gfx.text(c, hint, cx + cw - Gfx.w(hint), oy + 15, Gfx.DIM, e * 0.8f);

        List<Module> mods = Modules.in(sel);
        int total = 0;
        for (Module m : mods) {
            int sh = settingsH(m);
            total += ROW - 4 + Math.round(m.expand.v * (sh > 0 ? sh + 4 : 0)) + 4;
        }
        float maxScroll = Math.max(0, total - ch);
        scrollTarget = Gfx.clamp(scrollTarget, 0, maxScroll);
        int scroll = Math.round(scrollA.update(scrollTarget, 14));

        boolean inList = !closing && in(mx, my, cx, cy, cw, ch);
        c.enableScissor(cx, cy, cx + cw, cy + ch);
        int y = cy - scroll;
        for (Module m : mods) {
            int sh = settingsH(m);
            float ex = m.expand.update(m.expanded ? 1 : 0, 12);
            int card = ROW - 4 + Math.round(ex * (sh > 0 ? sh + 4 : 0));
            boolean hdr = inList && in(mx, my, cx, y, cw, ROW - 4);
            float hv = m.hover.update(hdr ? 1 : 0, 14);
            float on = m.guiOn.update(m.isEnabled() ? 1 : 0, 14);

            Gfx.rrect(c, cx, y, cw, card, 5, Gfx.col(Gfx.mix(Gfx.CARD, Gfx.CARD_H, hv), e));
            if (on > 0.02f) Gfx.rrect(c, cx, y + 5, 3, ROW - 14, 1, Gfx.col(Gfx.BLUE, on * e));
            Gfx.text(c, m.name, cx + 12, y + 5, Gfx.mix(Gfx.TEXT, Gfx.BLUE2, on), e);
            Gfx.text(c, m.description, cx + 12, y + 15, Gfx.DIM, e);
            Gfx.toggle(c, cx + cw - 36, y + (ROW - 4 - 12) / 2, on, e);
            if (sh > 0) {
                int dc = Gfx.col(Gfx.mix(Gfx.DIM, Gfx.BLUE2, ex), e);
                for (int k = 0; k < 3; k++) c.fill(cx + cw - 46, y + 9 + k * 4, cx + cw - 44, y + 11 + k * 4, dc);
            }
            if (lc && hdr) m.toggle();
            if (rc && hdr && sh > 0) m.expanded = !m.expanded;

            if (ex > 0.03f && sh > 0) {
                c.enableScissor(cx, y + ROW - 4, cx + cw, y + card);
                int sy2 = y + ROW - 2;
                float sa = e * ex;
                for (Module.Setting s : m.settings) {
                    if (s instanceof Module.Bool b) {
                        boolean row = inList && ex > 0.9f && in(mx, my, cx, sy2, cw, 20);
                        Gfx.text(c, b.name, cx + 12, sy2 + 6, Gfx.TEXT, sa);
                        Gfx.toggle(c, cx + cw - 36, sy2 + 4, b.anim.update(b.value ? 1 : 0, 14), sa);
                        if (lc && row) b.value = !b.value;
                    } else if (s instanceof Module.Num n) {
                        int tx = cx + 12, tw = cw - 24;
                        boolean row = inList && ex > 0.9f && in(mx, my, cx + 6, sy2 + 12, cw - 12, 16);
                        if (lc && row) dragging = n;
                        if (dragging == n && ld) {
                            double r = Math.max(0, Math.min(1, (mx - tx) / (double) tw));
                            double v = n.min + r * (n.max - n.min);
                            v = Math.round(v / n.step) * n.step;
                            n.value = Math.max(n.min, Math.min(n.max, v));
                        }
                        float rr = n.anim.update(n.ratio(), 22);
                        Gfx.text(c, n.name, cx + 12, sy2 + 3, Gfx.TEXT, sa);
                        String val = n.display();
                        Gfx.text(c, val, cx + cw - 12 - Gfx.w(val), sy2 + 3, Gfx.BLUE2, sa);
                        Gfx.rrect(c, tx, sy2 + 17, tw, 4, 2, Gfx.col(Gfx.OFF, sa));
                        int fw = Math.round(tw * rr);
                        Gfx.rrect(c, tx, sy2 + 17, Math.max(fw, 4), 4, 2, Gfx.col(Gfx.BLUE, sa));
                        Gfx.rrect(c, tx + fw - 3, sy2 + 15, 7, 8, 3, Gfx.col(0xFFFFFF, sa));
                    }
                    sy2 += settingH(s);
                }
                c.disableScissor();
            }
            y += card + 4;
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int bh = Math.max(16, Math.round(ch * (ch / (float) total)));
            int by = cy + Math.round((ch - bh) * (scroll / maxScroll));
            Gfx.rrect(c, cx + cw + 4, by, 2, bh, 1, Gfx.col(Gfx.BLUE, 0.7f * e));
        }

        Notifications.render(c);
    }
}
